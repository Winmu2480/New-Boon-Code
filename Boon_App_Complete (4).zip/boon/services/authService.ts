import * as AppleAuthentication from 'expo-apple-authentication';
import * as Crypto from 'expo-crypto';
import {
  GoogleAuthProvider,
  OAuthProvider,
  signInWithCredential,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  updateProfile,
  onAuthStateChanged,
  User as FirebaseUser,
} from 'firebase/auth';
import {
  doc, setDoc, getDoc, updateDoc, serverTimestamp,
} from 'firebase/firestore';
import { auth, db } from './firebase';
import { User } from '../types';

// ─── Auth State Listener ─────────────────────────────────────────────────────
export const subscribeToAuth = (callback: (user: FirebaseUser | null) => void) => {
  return onAuthStateChanged(auth, callback);
};

// ─── FIX #5: Token Auto-Refresh ──────────────────────────────────────────────
// Firebase tokens expire after 1 hour. This always returns a fresh valid token.
// Use before any authenticated API call instead of storing the token statically.
export const getFreshToken = async (): Promise<string | null> => {
  const user = auth.currentUser;
  if (!user) return null;
  try {
    return await user.getIdToken(true); // forceRefresh=true
  } catch {
    return null;
  }
};

// ─── Email / Password ────────────────────────────────────────────────────────
export const signInWithEmail = async (email: string, password: string) => {
  const result = await signInWithEmailAndPassword(auth, email, password);
  return result.user;
};

export const signUpWithEmail = async (
  email: string,
  password: string,
  displayName: string,
  username: string
) => {
  const result = await createUserWithEmailAndPassword(auth, email, password);
  await updateProfile(result.user, { displayName });
  await createUserDocument(result.user, { displayName, username });
  return result.user;
};

// ─── FIX #1: Google Sign-In ──────────────────────────────────────────────────
// Uses @react-native-google-signin/google-signin
// Setup: add your webClientId from Google Cloud Console to .env
// In GoogleSigninButton component call GoogleSignin.signIn() first
export const signInWithGoogleToken = async (idToken: string): Promise<FirebaseUser> => {
  const credential = GoogleAuthProvider.credential(idToken);
  const result = await signInWithCredential(auth, credential);
  await ensureUserDocument(result.user);
  return result.user;
};

// ─── FIX #2: Apple Sign-In ───────────────────────────────────────────────────
// Full implementation with nonce for security (required by Apple)
export const signInWithApple = async (): Promise<FirebaseUser> => {
  // Generate cryptographically secure nonce
  const rawNonce = generateNonce(32);
  const hashedNonce = await Crypto.digestStringAsync(
    Crypto.CryptoDigestAlgorithm.SHA256,
    rawNonce
  );

  // Request Apple credentials
  const appleCredential = await AppleAuthentication.signInAsync({
    requestedScopes: [
      AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
      AppleAuthentication.AppleAuthenticationScope.EMAIL,
    ],
    nonce: hashedNonce,
  });

  if (!appleCredential.identityToken) {
    throw new Error('Apple Sign-In failed: no identity token');
  }

  // Exchange for Firebase credential
  const provider = new OAuthProvider('apple.com');
  const firebaseCredential = provider.credential({
    idToken: appleCredential.identityToken,
    rawNonce,
  });

  const result = await signInWithCredential(auth, firebaseCredential);

  // Apple only sends name on FIRST sign-in — capture it immediately
  if (appleCredential.fullName?.givenName) {
    const displayName = [
      appleCredential.fullName.givenName,
      appleCredential.fullName.familyName,
    ].filter(Boolean).join(' ');
    await updateProfile(result.user, { displayName });
    await ensureUserDocument(result.user, { displayName });
  } else {
    await ensureUserDocument(result.user);
  }

  return result.user;
};

// ─── Sign Out ────────────────────────────────────────────────────────────────
export const signOutUser = async () => {
  await signOut(auth);
};

// ─── Firestore User Documents ────────────────────────────────────────────────
export const createUserDocument = async (
  firebaseUser: FirebaseUser,
  extra: { displayName?: string; username?: string } = {}
): Promise<User> => {
  const userRef = doc(db, 'users', firebaseUser.uid);
  const userData: User = {
    id: firebaseUser.uid,
    email: firebaseUser.email || '',
    displayName: extra.displayName || firebaseUser.displayName || 'Boon User',
    username: extra.username || generateUsername(firebaseUser.displayName || ''),
    avatar: firebaseUser.photoURL || null,
    bio: '',
    followersCount: 0,
    followingCount: 0,
    postsCount: 0,
    savedDeals: [],
    createdAt: new Date().toISOString(),
  };
  await setDoc(userRef, { ...userData, createdAt: serverTimestamp() });
  return userData;
};

export const ensureUserDocument = async (
  firebaseUser: FirebaseUser,
  extra?: { displayName?: string }
): Promise<User> => {
  const userRef = doc(db, 'users', firebaseUser.uid);
  const snap = await getDoc(userRef);
  if (!snap.exists()) {
    return createUserDocument(firebaseUser, extra);
  }
  return snap.data() as User;
};

export const getUserDocument = async (uid: string): Promise<User | null> => {
  const snap = await getDoc(doc(db, 'users', uid));
  return snap.exists() ? (snap.data() as User) : null;
};

export const updateUserProfile = async (uid: string, data: Partial<User>) => {
  await updateDoc(doc(db, 'users', uid), data);
};

// ─── Helpers ─────────────────────────────────────────────────────────────────
const generateUsername = (displayName: string): string => {
  const base = displayName.toLowerCase().replace(/[^a-z0-9]/g, '_').slice(0, 20);
  return (base || 'user') + Math.floor(Math.random() * 9999);
};

const generateNonce = (length: number): string => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
};
