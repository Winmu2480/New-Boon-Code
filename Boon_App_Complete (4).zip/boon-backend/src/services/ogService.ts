import axios from 'axios';
import * as cheerio from 'cheerio';
import { getPool } from '../config/database';

export interface OGMetadata {
  title: string;
  description: string;
  image: string;
  siteName: string;
  url: string;
}

const FETCH_TIMEOUT = 8000;
const CACHE_TTL_HOURS = 24;

// ── Main OG Fetch (with PostgreSQL cache) ────────────────────────────────────
export const fetchOGMetadata = async (url: string): Promise<OGMetadata> => {
  const db = getPool();

  // 1. Check cache
  const cached = await db.query(
    `SELECT title, description, image, site_name
     FROM og_cache
     WHERE url = $1 AND expires_at > NOW()`,
    [url]
  );

  if (cached.rows.length > 0) {
    const row = cached.rows[0];
    return {
      title: row.title || '',
      description: row.description || '',
      image: row.image || '',
      siteName: row.site_name || '',
      url,
    };
  }

  // 2. Fetch fresh
  const metadata = await scrapeOGTags(url);

  // 3. Upsert into cache
  await db.query(
    `INSERT INTO og_cache (url, title, description, image, site_name, expires_at)
     VALUES ($1, $2, $3, $4, $5, NOW() + INTERVAL '${CACHE_TTL_HOURS} hours')
     ON CONFLICT (url) DO UPDATE SET
       title = EXCLUDED.title,
       description = EXCLUDED.description,
       image = EXCLUDED.image,
       site_name = EXCLUDED.site_name,
       fetched_at = NOW(),
       expires_at = NOW() + INTERVAL '${CACHE_TTL_HOURS} hours'`,
    [url, metadata.title, metadata.description, metadata.image, metadata.siteName]
  );

  return metadata;
};

// ── HTML Scraper ──────────────────────────────────────────────────────────────
const scrapeOGTags = async (url: string): Promise<OGMetadata> => {
  const response = await axios.get(url, {
    timeout: FETCH_TIMEOUT,
    headers: {
      'User-Agent':
        'Mozilla/5.0 (compatible; BoonBot/1.0; +https://boonapp.com/bot)',
      Accept: 'text/html,application/xhtml+xml',
      'Accept-Language': 'en-US,en;q=0.9',
    },
    maxRedirects: 5,
    // Only fetch enough HTML to find OG tags (first 50KB)
    maxContentLength: 50 * 1024,
  });

  const $ = cheerio.load(response.data);

  const getMeta = (property: string): string =>
    $(`meta[property="${property}"]`).attr('content') ||
    $(`meta[name="${property}"]`).attr('content') ||
    '';

  const title =
    getMeta('og:title') ||
    getMeta('twitter:title') ||
    $('title').text() ||
    '';

  const description =
    getMeta('og:description') ||
    getMeta('twitter:description') ||
    getMeta('description') ||
    '';

  const image =
    getMeta('og:image') ||
    getMeta('twitter:image') ||
    getMeta('twitter:image:src') ||
    '';

  const siteName =
    getMeta('og:site_name') ||
    new URL(url).hostname.replace('www.', '') ||
    '';

  return {
    title: title.trim().slice(0, 200),
    description: description.trim().slice(0, 500),
    image: resolveImageUrl(image, url),
    siteName: siteName.trim().slice(0, 100),
    url,
  };
};

// ── Resolve relative image URLs ───────────────────────────────────────────────
const resolveImageUrl = (imageUrl: string, baseUrl: string): string => {
  if (!imageUrl) return '';
  try {
    return new URL(imageUrl, baseUrl).href;
  } catch {
    return imageUrl;
  }
};
