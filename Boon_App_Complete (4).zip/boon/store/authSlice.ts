import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import { AuthState, User } from '../types';
import {
  signInWithEmail,
  signUpWithEmail,
  signOutUser,
  getUserDocument,
} from '../services/authService';

const initialState: AuthState = {
  user: null,
  token: null,
  isLoading: false,
  error: null,
};

// ─── Async Thunks ──────────────────────────────────────────────────────────────

export const loginWithEmail = createAsyncThunk(
  'auth/loginWithEmail',
  async ({ email, password }: { email: string; password: string }, { rejectWithValue }) => {
    try {
      const fbUser = await signInWithEmail(email, password);
      const user = await getUserDocument(fbUser.uid);
      const token = await fbUser.getIdToken();
      if (!user) throw new Error('User profile not found');
      return { user, token };
    } catch (err: any) {
      const msg = friendlyAuthError(err.code || err.message);
      return rejectWithValue(msg);
    }
  }
);

export const registerWithEmail = createAsyncThunk(
  'auth/registerWithEmail',
  async (
    { email, password, displayName, username }: {
      email: string; password: string; displayName: string; username: string;
    },
    { rejectWithValue }
  ) => {
    try {
      const fbUser = await signUpWithEmail(email, password, displayName, username);
      const user = await getUserDocument(fbUser.uid);
      const token = await fbUser.getIdToken();
      if (!user) throw new Error('Failed to create profile');
      return { user, token };
    } catch (err: any) {
      const msg = friendlyAuthError(err.code || err.message);
      return rejectWithValue(msg);
    }
  }
);

export const logout = createAsyncThunk('auth/logout', async () => {
  await signOutUser();
});

// ─── Slice ────────────────────────────────────────────────────────────────────

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    // Used by social sign-in (Google/Apple) and token refresh in root index
    setUser: (state, action: PayloadAction<{ user: User; token: string }>) => {
      state.user = action.payload.user;
      state.token = action.payload.token;
      state.isLoading = false;
      state.error = null;
    },
    // Used by root index when Firebase fires onAuthStateChanged with null
    clearAuth: (state) => {
      state.user = null;
      state.token = null;
      state.error = null;
    },
    clearError: (state) => {
      state.error = null;
    },
    // Used by Edit Profile after a successful save
    updateUser: (state, action: PayloadAction<Partial<User>>) => {
      if (state.user) {
        state.user = { ...state.user, ...action.payload };
      }
    },
    // FIX #5: Called by apiClient when a fresh token is obtained
    refreshToken: (state, action: PayloadAction<string>) => {
      state.token = action.payload;
    },
  },
  extraReducers: (builder) => {
    // loginWithEmail
    builder
      .addCase(loginWithEmail.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(loginWithEmail.fulfilled, (state, action) => {
        state.isLoading = false;
        state.user = action.payload.user;
        state.token = action.payload.token;
      })
      .addCase(loginWithEmail.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      });

    // registerWithEmail
    builder
      .addCase(registerWithEmail.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(registerWithEmail.fulfilled, (state, action) => {
        state.isLoading = false;
        state.user = action.payload.user;
        state.token = action.payload.token;
      })
      .addCase(registerWithEmail.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      });

    // logout
    builder.addCase(logout.fulfilled, (state) => {
      state.user = null;
      state.token = null;
      state.error = null;
    });
  },
});

export const { setUser, clearAuth, clearError, updateUser, refreshToken } = authSlice.actions;
export default authSlice.reducer;

// ─── Human-readable Firebase error messages ───────────────────────────────────
function friendlyAuthError(code: string): string {
  switch (code) {
    case 'auth/user-not-found':
    case 'auth/wrong-password':
    case 'auth/invalid-credential':
      return 'Incorrect email or password.';
    case 'auth/email-already-in-use':
      return 'An account with this email already exists.';
    case 'auth/weak-password':
      return 'Password must be at least 6 characters.';
    case 'auth/invalid-email':
      return 'Please enter a valid email address.';
    case 'auth/too-many-requests':
      return 'Too many attempts. Please wait a moment and try again.';
    case 'auth/network-request-failed':
      return 'Network error. Please check your connection.';
    case 'auth/user-disabled':
      return 'This account has been disabled.';
    default:
      return code || 'Something went wrong. Please try again.';
  }
}
