import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import { initFirebase } from './config/firebase';
import { getPool, runMigrations } from './config/database';
import routes from './routes';
import { errorHandler, notFound } from './middleware/errorHandler';

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);

// ── Security & Parsing Middleware ─────────────────────────────────────────────
app.use(helmet());
app.use(cors({
  origin: (process.env.ALLOWED_ORIGINS || 'http://localhost:8081')
    .split(',')
    .map((o) => o.trim()),
  credentials: true,
}));
app.use(express.json({ limit: '5mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// ── API Routes ────────────────────────────────────────────────────────────────
app.use('/api', routes);

// ── Error Handling ────────────────────────────────────────────────────────────
app.use(notFound);
app.use(errorHandler);

// ── Startup ───────────────────────────────────────────────────────────────────
const start = async () => {
  try {
    // Initialize Firebase Admin
    initFirebase();

    // Run PostgreSQL migrations
    await runMigrations();

    app.listen(PORT, () => {
      console.log(`
╔══════════════════════════════════════╗
║  🛍️  Boon API Server                 ║
║  Running on port ${PORT}               ║
║  ENV: ${(process.env.NODE_ENV || 'development').padEnd(27)}║
╚══════════════════════════════════════╝
      `);
    });
  } catch (err) {
    console.error('❌ Failed to start server:', err);
    process.exit(1);
  }
};

start();

export default app;
