import { Request, Response, NextFunction } from 'express';
import { z } from 'zod';
import { getFirestore } from '../config/firebase';
import { AuthRequest } from '../middleware/auth';
import { createNotification } from '../services/notificationService';
import { trackEvent } from '../services/analyticsService';

// ── GET /api/posts/feed ───────────────────────────────────────────────────────
export const getFeed = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const db = getFirestore();
    const userId = req.user!.uid;
    const limit = parseInt(req.query.limit as string) || 10;
    const cursor = req.query.cursor as string | undefined;

    // Get user's following list
    const userSnap = await db.collection('users').doc(userId).get();
    const following: string[] = userSnap.data()?.following || [];

    // Include own posts + following posts
    const authorIds = [userId, ...following].slice(0, 10);

    if (authorIds.length === 0) {
      res.json({ success: true, data: [], hasMore: false });
      return;
    }

    let query = db
      .collection('posts')
      .where('authorId', 'in', authorIds)
      .orderBy('createdAt', 'desc')
      .limit(limit + 1);

    if (cursor) {
      const cursorDoc = await db.collection('posts').doc(cursor).get();
      if (cursorDoc.exists) query = query.startAfter(cursorDoc);
    }

    const snap = await query.get();
    const posts = snap.docs.slice(0, limit).map((d) => ({
      id: d.id,
      ...d.data(),
      isLiked: (d.data().likedBy || []).includes(userId),
      isSaved: (d.data().savedBy || []).includes(userId),
    }));

    res.json({
      success: true,
      data: posts,
      hasMore: snap.docs.length > limit,
      nextCursor: snap.docs.length > limit ? snap.docs[limit - 1].id : null,
    });
  } catch (err) {
    next(err);
  }
};

// ── GET /api/posts/discover ───────────────────────────────────────────────────
export const getDiscover = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const db = getFirestore();
    const userId = req.user?.uid;
    const limit = parseInt(req.query.limit as string) || 10;
    const cursor = req.query.cursor as string | undefined;

    let query = db
      .collection('posts')
      .orderBy('createdAt', 'desc')
      .limit(limit + 1);

    if (cursor) {
      const cursorDoc = await db.collection('posts').doc(cursor).get();
      if (cursorDoc.exists) query = query.startAfter(cursorDoc);
    }

    const snap = await query.get();
    const posts = snap.docs.slice(0, limit).map((d) => ({
      id: d.id,
      ...d.data(),
      isLiked: userId ? (d.data().likedBy || []).includes(userId) : false,
      isSaved: userId ? (d.data().savedBy || []).includes(userId) : false,
    }));

    res.json({
      success: true,
      data: posts,
      hasMore: snap.docs.length > limit,
      nextCursor: snap.docs.length > limit ? snap.docs[limit - 1].id : null,
    });
  } catch (err) {
    next(err);
  }
};

// ── POST /api/posts/:id/like ──────────────────────────────────────────────────
export const likePost = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { id } = req.params;
    const userId = req.user!.uid;
    const db = getFirestore();

    const postRef = db.collection('posts').doc(id);
    const snap = await postRef.get();
    if (!snap.exists) { res.status(404).json({ error: 'Post not found' }); return; }

    const data = snap.data()!;
    const likedBy: string[] = data.likedBy || [];
    const isLiked = likedBy.includes(userId);

    await postRef.update({
      likesCount: Math.max(0, (data.likesCount || 0) + (isLiked ? -1 : 1)),
      likedBy: isLiked
        ? likedBy.filter((u) => u !== userId)
        : [...likedBy, userId],
    });

    // Notify post author (not if liking own post)
    if (!isLiked && data.authorId !== userId) {
      const userSnap = await db.collection('users').doc(userId).get();
      await createNotification({
        userId: data.authorId,
        type: 'like',
        actorId: userId,
        postId: id,
        message: `${userSnap.data()?.displayName || 'Someone'} liked your post`,
      });
    }

    res.json({ success: true, isLiked: !isLiked });
  } catch (err) {
    next(err);
  }
};

// ── POST /api/posts/:id/save ──────────────────────────────────────────────────
export const savePost = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { id } = req.params;
    const userId = req.user!.uid;
    const db = getFirestore();
    const batch = db.batch();

    const postRef = db.collection('posts').doc(id);
    const userRef = db.collection('users').doc(userId);
    const [postSnap, userSnap] = await Promise.all([postRef.get(), userRef.get()]);

    if (!postSnap.exists) { res.status(404).json({ error: 'Post not found' }); return; }

    const postData = postSnap.data()!;
    const userData = userSnap.data()!;
    const savedBy: string[] = postData.savedBy || [];
    const isSaved = savedBy.includes(userId);

    batch.update(postRef, {
      savesCount: Math.max(0, (postData.savesCount || 0) + (isSaved ? -1 : 1)),
      savedBy: isSaved ? savedBy.filter((u) => u !== userId) : [...savedBy, userId],
    });
    batch.update(userRef, {
      savedDeals: isSaved
        ? (userData.savedDeals || []).filter((p: string) => p !== id)
        : [...(userData.savedDeals || []), id],
    });

    await batch.commit();
    res.json({ success: true, isSaved: !isSaved });
  } catch (err) {
    next(err);
  }
};

// ── GET /api/posts/:id/comments ───────────────────────────────────────────────
export const getComments = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { id } = req.params;
    const db = getFirestore();
    const snap = await db
      .collection('posts').doc(id)
      .collection('comments')
      .orderBy('createdAt', 'asc')
      .limit(50)
      .get();

    const comments = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    res.json({ success: true, data: comments });
  } catch (err) {
    next(err);
  }
};

// ── POST /api/posts/:id/comments ──────────────────────────────────────────────
export const addComment = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { id } = req.params;
    const { text } = z.object({ text: z.string().min(1).max(500) }).parse(req.body);
    const userId = req.user!.uid;
    const db = getFirestore();

    const postRef = db.collection('posts').doc(id);
    const postSnap = await postRef.get();
    if (!postSnap.exists) { res.status(404).json({ error: 'Post not found' }); return; }

    const commentRef = await db
      .collection('posts').doc(id)
      .collection('comments')
      .add({
        postId: id,
        authorId: userId,
        text,
        likesCount: 0,
        createdAt: new Date().toISOString(),
      });

    await postRef.update({ commentsCount: (postSnap.data()!.commentsCount || 0) + 1 });

    // Notify post author
    const postData = postSnap.data()!;
    if (postData.authorId !== userId) {
      const userSnap = await db.collection('users').doc(userId).get();
      await createNotification({
        userId: postData.authorId,
        type: 'comment',
        actorId: userId,
        postId: id,
        message: `${userSnap.data()?.displayName || 'Someone'} commented on your post`,
      });
    }

    res.status(201).json({ success: true, data: { id: commentRef.id, text, authorId: userId } });
  } catch (err) {
    next(err);
  }
};

// ── POST /api/posts/:id/track-click ──────────────────────────────────────────
export const trackStoreClick = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { id } = req.params;
    const db = getFirestore();
    const snap = await db.collection('posts').doc(id).get();
    if (!snap.exists) { res.status(404).json({ error: 'Post not found' }); return; }

    await trackEvent({
      userId: req.user?.uid,
      eventType: 'store_url_click',
      postId: id,
      storeUrl: snap.data()!.storeUrl,
    });

    res.json({ success: true });
  } catch (err) {
    next(err);
  }
};
