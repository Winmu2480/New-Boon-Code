#!/bin/bash
# ─── Boon Backend — Railway Deploy Script ────────────────────────────────────
# Deploys the Node.js backend to Railway in ~3 minutes.
# Prerequisites: npm install -g @railway/cli  AND  railway login
#
# Usage: chmod +x deploy.sh && ./deploy.sh

set -e

echo ""
echo "🚀 Deploying Boon backend to Railway..."
echo ""

# ── Check Railway CLI installed ───────────────────────────────────────────────
if ! command -v railway &> /dev/null; then
  echo "❌ Railway CLI not found. Install it:"
  echo "   npm install -g @railway/cli"
  echo "   railway login"
  exit 1
fi

# ── Check logged in ───────────────────────────────────────────────────────────
if ! railway whoami &> /dev/null; then
  echo "❌ Not logged in to Railway. Run: railway login"
  exit 1
fi

# ── Init project if not already done ─────────────────────────────────────────
if [ ! -f ".railway/config.json" ]; then
  echo "📋 Initialising Railway project..."
  railway init --name "boon-api"
fi

# ── Check required env vars are set ──────────────────────────────────────────
echo "🔑 Checking required environment variables..."
REQUIRED=(
  "FIREBASE_PROJECT_ID"
  "FIREBASE_CLIENT_EMAIL"
  "FIREBASE_PRIVATE_KEY"
  "OPENAI_API_KEY"
  "NODE_ENV"
)

MISSING_VARS=()
for var in "${REQUIRED[@]}"; do
  if ! railway variables get "$var" &>/dev/null; then
    MISSING_VARS+=("$var")
  fi
done

if [ ${#MISSING_VARS[@]} -gt 0 ]; then
  echo ""
  echo "⚠️  Missing Railway environment variables. Set them in the Railway dashboard:"
  echo "   railway.app → your project → Variables"
  echo ""
  echo "   Required variables:"
  for v in "${MISSING_VARS[@]}"; do
    echo "   - $v"
  done
  echo ""
  echo "   Or set them via CLI:"
  echo "   railway variables set FIREBASE_PROJECT_ID=your-project-id"
  echo ""
  read -p "Continue deploying anyway? (y/N) " confirm
  [[ $confirm == [yY] ]] || exit 1
fi

# ── Deploy ────────────────────────────────────────────────────────────────────
echo ""
echo "📦 Building and deploying..."
railway up --detach

# ── Get the URL ───────────────────────────────────────────────────────────────
echo ""
echo "⏳ Waiting for deployment URL..."
sleep 5

DEPLOY_URL=$(railway status --json 2>/dev/null | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('deploymentUrl',''))" 2>/dev/null || echo "")

echo ""
echo "✅ Deployment triggered!"
echo ""
if [ -n "$DEPLOY_URL" ]; then
  echo "🌐 Your API URL: https://$DEPLOY_URL"
  echo ""
  echo "📱 Add this to your mobile app .env:"
  echo "   EXPO_PUBLIC_API_URL=https://$DEPLOY_URL"
else
  echo "🌐 Get your API URL from: railway.app → your project → Deployments"
  echo "   Then add it to your mobile .env: EXPO_PUBLIC_API_URL=https://your-url.railway.app"
fi

echo ""
echo "🔒 Don't forget to set these in Railway dashboard:"
echo "   PORT=3000"
echo "   NODE_ENV=production"
echo "   DATABASE_URL=(auto-set when you add Railway PostgreSQL plugin)"
echo "   REDIS_URL=(auto-set when you add Railway Redis plugin)"
echo ""
echo "📌 Add Railway plugins in dashboard:"
echo "   Railway project → + New → PostgreSQL"
echo "   Railway project → + New → Redis"
echo ""
echo "Test your API: curl https://YOUR_URL.railway.app/api/health"
