# Boon App — Final Setup Checklist

Everything in this file requires YOU to do it because it involves external accounts.
All the code is already written and waiting. Just follow these steps.

Estimated time: 45 minutes total.

---

## Step 1 — Download Fonts (5 minutes)

Run this from the `boon/` folder:

```bash
chmod +x scripts/download-fonts.sh
./scripts/download-fonts.sh
```

If the script fails (network issues), download manually from fonts.google.com:
- **Playfair Display** → select Bold → Download family → rename to `PlayfairDisplay-Bold.ttf`
- **DM Sans** → select Regular, Medium, Bold weights → rename accordingly
- **Space Mono** → select Regular → rename to `SpaceMono-Regular.ttf`

Place all 5 `.ttf` files in `boon/assets/fonts/`

---

## Step 2 — Firebase Security Rules (10 minutes) ⚠️ CRITICAL

**Your database is open to the public until you do this.**

### Firestore Rules:
1. Go to [console.firebase.google.com](https://console.firebase.google.com)
2. Select your Boon project
3. Left sidebar → **Firestore Database** → **Rules** tab
4. Delete everything and paste the full contents of `boon/firestore.rules`
5. Click **Publish**

### Storage Rules:
1. Left sidebar → **Storage** → **Rules** tab
2. Delete everything and paste the full contents of `boon/storage.rules`
3. Click **Publish**

---

## Step 3 — Google Sign-In Setup (15 minutes)

### A. Create OAuth Client IDs

1. Go to [console.cloud.google.com](https://console.cloud.google.com)
2. Select your Firebase project (same project)
3. APIs & Services → **Credentials** → **+ Create Credentials** → OAuth 2.0 Client ID

Create **4 separate client IDs**:

| Type | Settings |
|---|---|
| **Web application** | Name: Boon Web |
| **iOS** | Bundle ID: `com.boonapp.boon` |
| **Android** | Package: `com.boonapp.boon`, SHA-1: (see below) |
| **Web** (for Expo) | Name: Boon Expo |

**Get your Android SHA-1 fingerprint:**
```bash
# Debug keystore (for development):
keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android

# Or let EAS handle it automatically when you run: eas build
```

### B. Add to your .env file

```bash
# boon/.env
EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID=YOUR_WEB_CLIENT_ID.apps.googleusercontent.com
EXPO_PUBLIC_GOOGLE_IOS_CLIENT_ID=YOUR_IOS_CLIENT_ID.apps.googleusercontent.com
EXPO_PUBLIC_GOOGLE_ANDROID_CLIENT_ID=YOUR_ANDROID_CLIENT_ID.apps.googleusercontent.com
EXPO_PUBLIC_GOOGLE_EXPO_CLIENT_ID=YOUR_EXPO_WEB_CLIENT_ID.apps.googleusercontent.com
```

### C. Update app.json

In `boon/app.json`, find this line in the plugins section:
```json
"iosUrlScheme": "com.googleusercontent.apps.YOUR_IOS_CLIENT_ID"
```
Replace `YOUR_IOS_CLIENT_ID` with the actual numeric ID part of your iOS client ID.
Example: if your iOS client ID is `12345678-abc.apps.googleusercontent.com`,
the iosUrlScheme should be: `com.googleusercontent.apps.12345678-abc`

### D. Enable in Firebase

Firebase Console → Authentication → **Sign-in method** → Google → **Enable** → Save

---

## Step 4 — Apple Sign-In Setup (10 minutes)

The code is already written. Just enable the capability.

1. Go to [developer.apple.com](https://developer.apple.com) → Certificates, IDs & Profiles
2. Click **Identifiers** → find `com.boonapp.boon`
3. Scroll to **Capabilities** → check **Sign In with Apple**
4. Click **Edit** → set as **Primary App ID** → **Save**

Then in Firebase:
1. Firebase Console → Authentication → **Sign-in method** → Apple
2. Click **Enable** → **Save**
3. You may need to enter your Team ID (found in developer.apple.com top right corner)

No client ID needed in your .env — Apple Sign-In uses your Bundle ID automatically.

---

## Step 5 — Deploy Backend to Railway (5 minutes)

```bash
# Install Railway CLI (once)
npm install -g @railway/cli

# Log in
railway login

# Deploy from the backend folder
cd boon-backend
chmod +x deploy.sh
./deploy.sh
```

In the **Railway dashboard** after deploy:
1. Add a **PostgreSQL** plugin: New → Database → PostgreSQL
2. Add a **Redis** plugin: New → Database → Redis
3. Go to **Variables** and add:

| Variable | Value |
|---|---|
| `NODE_ENV` | `production` |
| `PORT` | `3000` |
| `FIREBASE_PROJECT_ID` | your Firebase project ID |
| `FIREBASE_CLIENT_EMAIL` | from Firebase service account JSON |
| `FIREBASE_PRIVATE_KEY` | from Firebase service account JSON (include the full key with newlines) |
| `OPENAI_API_KEY` | your OpenAI API key |
| `ALLOWED_ORIGINS` | `*` (or your app's URL) |

`DATABASE_URL` and `REDIS_URL` are set automatically by Railway when you add the plugins.

4. Copy your Railway deployment URL (e.g. `https://boon-api-production.up.railway.app`)
5. Add it to `boon/.env`:

```bash
EXPO_PUBLIC_API_URL=https://boon-api-production.up.railway.app
```

### Verify it works:
```bash
curl https://YOUR_URL.railway.app/api/health
# Should return: {"status":"ok","version":"1.0.0"}
```

---

## Step 6 — Expo Project ID (for push notifications)

1. Go to [expo.dev](https://expo.dev) → log in or create account
2. Create a new project called **boon**
3. Copy the **Project ID** (looks like: `xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx`)
4. Add to `boon/.env`:

```bash
EXPO_PUBLIC_EXPO_PROJECT_ID=your-expo-project-id
```

5. Also add it to `boon/app.json` under `expo.extra.eas.projectId`

---

## Final Check — Run the App

```bash
cd boon
npm install
npx expo start
```

Scan the QR code with **Expo Go** on your phone. All 14 screens should work.

---

## Completion After These Steps: ~95%

The remaining 5% is:
- App Store screenshots (design work)
- App Store listing copy (marketing copy)
- Apple Developer account ($99/yr) for final submission
- Google Play Console account ($25 one-time) for final submission

---

## Quick Reference

| Task | Time | Requires |
|---|---|---|
| Download fonts | 5 min | Terminal |
| Apply Firebase Security Rules | 10 min | Firebase Console |
| Google OAuth setup | 15 min | Google Cloud Console |
| Apple Sign-In entitlement | 10 min | Apple Developer account |
| Deploy backend to Railway | 5 min | Terminal + Railway account (free) |
| Expo project ID | 5 min | expo.dev (free) |
