import { Request, Response, NextFunction } from 'express';
import { AuthRequest } from '../middleware/auth';
import {
  getDailyActiveUsers,
  getStoreClickThroughRate,
  getDealFinderStats,
  getTopStores,
  trackEvent,
} from '../services/analyticsService';

// GET /api/analytics/dashboard (admin)
export const getDashboard = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const [dau, ctr, dealStats, topStores] = await Promise.all([
      getDailyActiveUsers(30),
      getStoreClickThroughRate(30),
      getDealFinderStats(7),
      getTopStores(10),
    ]);

    res.json({
      success: true,
      data: {
        dailyActiveUsers: dau,
        clickThroughRate: ctr,
        dealFinder: dealStats,
        topStores,
      },
    });
  } catch (err) {
    next(err);
  }
};

// POST /api/analytics/track
export const track = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { eventType, postId, storeUrl, metadata } = req.body;
    await trackEvent({
      userId: req.user?.uid,
      eventType,
      postId,
      storeUrl,
      metadata,
    });
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
};
