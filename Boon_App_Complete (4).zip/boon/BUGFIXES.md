# Boon App — 6 Bug Fixes Applied

All 6 production bugs have been fixed in this update.
Below is exactly what changed and any one-time setup steps you need to complete.

---

## Fix 1 — Google Sign-In (fully wired)

**What was wrong:** Button existed but nothing happened when tapped.

**What changed:**
- `services/authService.ts` — `signInWithGoogleToken()` now exchanges a real Google ID token for a Firebase credential
- `app/(auth)/login.tsx` — `handleGoogleSignIn()` calls `@react-native-google-signin/google-signin`, gets the token, passes it to Firebase

**One-time setup (you must do this):**

1. Go to [console.cloud.google.com](https://console.cloud.google.com)
2. Select your project → APIs & Services → Credentials → Create OAuth Client ID
3. Create 4 client IDs: Web, iOS, Android, Expo
4. Copy the values into your `.env`:
```
EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID=xxx.apps.googleusercontent.com
EXPO_PUBLIC_GOOGLE_IOS_CLIENT_ID=xxx.apps.googleusercontent.com
EXPO_PUBLIC_GOOGLE_ANDROID_CLIENT_ID=xxx.apps.googleusercontent.com
EXPO_PUBLIC_GOOGLE_EXPO_CLIENT_ID=xxx.apps.googleusercontent.com
```
5. In `app.json`, replace `YOUR_IOS_CLIENT_ID` in the plugin config with your real iOS client ID (the reversed form, e.g. `com.googleusercontent.apps.xxx`)
6. Enable Google as a sign-in provider in Firebase Console → Authentication → Sign-in method → Google

---

## Fix 2 — Apple Sign-In (fully wired)

**What was wrong:** Button existed but nothing happened when tapped. Apple sign-in is required by Apple if you offer any social login.

**What changed:**
- `services/authService.ts` — `signInWithApple()` now generates a secure SHA-256 nonce, requests Apple credentials via `expo-apple-authentication`, exchanges for Firebase credential, and captures the user's name (Apple only sends it on first sign-in)
- `app/(auth)/login.tsx` — Apple button is conditionally shown (iOS 13+ only) and calls the real flow

**One-time setup:**

1. In Firebase Console → Authentication → Sign-in method → Enable **Apple**
2. In Apple Developer portal → Certificates, IDs & Profiles → Identifiers → your App ID → enable **Sign in with Apple**
3. Add the Apple capability in `app.json` (already done — `"expo-apple-authentication"` plugin is added)
4. No client ID needed — Apple Sign-In uses your Bundle ID automatically

---

## Fix 3 — Author data missing on feed posts

**What was wrong:** Every post in the feed showed a blank avatar and "Boon User" because `post.author` was undefined — the post document only stored `authorId`, requiring a join that never happened.

**What changed:**
- `services/postService.ts` — `createPost()` now writes a lightweight `author` snapshot (id, displayName, username, avatar) directly into the post document at creation time. No join needed on read.
- `services/postService.ts` — `embedAuthor()` helper batch-fetches author profiles for any legacy posts that don't have the embedded snapshot, so old posts still work.
- Feed queries return posts with author data populated immediately.

**No setup needed** — works automatically for all new posts. Old posts will have authors resolved via the batch-fetch fallback.

---

## Fix 4 — Infinite scroll stopped after 10 posts

**What was wrong:** `FlashList` had no `onEndReached` handler. The feed fetched one page and stopped — users could never scroll past the first 10 posts.

**What changed:**
- `store/feedSlice.ts` — new `loadMoreFeed` thunk uses a Firestore `DocumentSnapshot` cursor (stored in a module-level cache outside Redux, since `DocumentSnapshot` isn't serializable) to fetch the next page and append it to the existing posts with deduplication
- `app/(tabs)/index.tsx` — `FlashList` now has `onEndReached={onEndReached}` and `onEndReachedThreshold={0.4}`, plus a loading spinner footer while more posts load

**No setup needed** — works automatically.

---

## Fix 5 — Users silently logged out after 1 hour

**What was wrong:** Firebase ID tokens expire after 60 minutes. The app stored the token from login and never refreshed it, so API calls started failing silently after an hour.

**What changed:**
- `services/authService.ts` — new `getFreshToken()` function calls `user.getIdToken(true)` which triggers Firebase to refresh if expiry is within 5 minutes
- `services/apiClient.ts` — new authenticated API client calls `getFreshToken()` before EVERY request, so the token is always valid
- `app/index.tsx` — `onAuthStateChanged` listener in the root now calls `getIdToken(false)` (not force-refresh) on app open to restore session, and Firebase internally handles the periodic silent refresh

**No setup needed** — replace any direct `fetch()` calls to your backend with `api.get()` / `api.post()` from `services/apiClient.ts` to get automatic token refresh on every call.

---

## Fix 6 — Firebase Security Rules not applied

**What was wrong:** Without rules, any user could read and write any other user's data. Your database was completely open.

**What changed:**
- `firestore.rules` — production-ready Firestore rules:
  - Users can only edit their own profile
  - Posts require authentication to read; only the author can delete
  - Social interactions (likes/saves) allowed by any signed-in user
  - Notifications read-only for the recipient
  - All other collections blocked
- `storage.rules` — Firebase Storage rules:
  - Post images: 10MB max, images only, owner upload
  - Avatars: 5MB max, images only, owner upload
  - Everything else blocked

**One-time setup (critical — do this before going live):**

### Firestore Rules:
1. Open [Firebase Console](https://console.firebase.google.com) → your project
2. Left sidebar → **Firestore Database** → **Rules** tab
3. Delete the existing rules and paste the entire contents of `firestore.rules`
4. Click **Publish**

### Storage Rules:
1. Left sidebar → **Storage** → **Rules** tab
2. Delete existing rules and paste the entire contents of `storage.rules`
3. Click **Publish**

---

## Summary of files changed

| File | Fix |
|---|---|
| `services/authService.ts` | Fix 1, 2, 5 — Google, Apple, token refresh |
| `app/(auth)/login.tsx` | Fix 1, 2 — social auth wired to UI |
| `services/postService.ts` | Fix 3 — author denormalization |
| `services/apiClient.ts` | Fix 5 — authenticated client (new file) |
| `store/feedSlice.ts` | Fix 4 — infinite scroll cursor |
| `store/authSlice.ts` | Fix 5 — refreshToken action, friendly errors |
| `app/(tabs)/index.tsx` | Fix 4 — onEndReached wired |
| `app/index.tsx` | Fix 5 — token refresh on session restore |
| `app.json` | Fix 1, 2 — Google + Apple plugins |
| `.env.example` | Fix 1 — Google client ID vars |
| `firestore.rules` | Fix 6 — database security (new file) |
| `storage.rules` | Fix 6 — storage security (new file) |
