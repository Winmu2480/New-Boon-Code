import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  Image, RefreshControl, ActivityIndicator, StatusBar,
} from 'react-native';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { Colors, Typography, Spacing, Radius, Shadow } from '../../constants/theme';
import { api } from '../../services/apiClient';

interface Notification {
  id: string;
  type: 'like' | 'comment' | 'follow' | 'deal_alert' | 'price_drop';
  actorId: string;
  actor?: { displayName: string; avatar: string | null; username: string };
  postId?: string;
  message: string;
  isRead: boolean;
  createdAt: string;
}

// Map notification type → icon name + color
const TYPE_META: Record<string, { icon: string; color: string; bg: string }> = {
  like:        { icon: 'heart',         color: Colors.primary,   bg: Colors.primaryLight },
  comment:     { icon: 'message-circle',color: '#6366F1',        bg: '#EEEEFF' },
  follow:      { icon: 'user-plus',     color: '#1A8A5A',        bg: Colors.successLight },
  deal_alert:  { icon: 'zap',           color: Colors.gold,      bg: '#FDF5E6' },
  price_drop:  { icon: 'trending-down', color: '#1A8A5A',        bg: Colors.successLight },
};

export default function NotificationsScreen() {
  const insets = useSafeAreaInsets();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const loadNotifications = useCallback(async () => {
    try {
      const res = await api.get<{ success: boolean; data: Notification[]; unreadCount: number }>(
        '/api/notifications', { limit: '50' }
      );
      if (res.success) {
        setNotifications(res.data);
        setUnreadCount(res.unreadCount);
      }
    } catch (err) {
      console.error('Failed to load notifications:', err);
    }
    setLoading(false);
    setRefreshing(false);
  }, []);

  useEffect(() => {
    loadNotifications();
  }, []);

  // Mark all as read when screen mounts
  useEffect(() => {
    if (!loading && unreadCount > 0) {
      api.post('/api/notifications/read', {}).catch(() => {});
    }
  }, [loading, unreadCount]);

  const onRefresh = () => {
    setRefreshing(true);
    loadNotifications();
  };

  const handleNotificationPress = (n: Notification) => {
    if (n.postId) {
      router.push({ pathname: '/post/[id]', params: { id: n.postId } });
    } else if (n.actorId && n.type === 'follow') {
      router.push({ pathname: '/profile/[id]', params: { id: n.actorId } });
    }
  };

  const renderNotification = ({ item, index }: { item: Notification; index: number }) => {
    const meta = TYPE_META[item.type] || TYPE_META.like;
    const isFirst = index === 0;
    const showDateHeader =
      isFirst ||
      getDateGroup(item.createdAt) !== getDateGroup(notifications[index - 1]?.createdAt);

    return (
      <>
        {showDateHeader && (
          <Text style={styles.dateHeader}>{getDateGroup(item.createdAt)}</Text>
        )}
        <TouchableOpacity
          style={[styles.row, !item.isRead && styles.rowUnread]}
          onPress={() => handleNotificationPress(item)}
          activeOpacity={0.7}
        >
          {/* Unread dot */}
          {!item.isRead && <View style={styles.unreadDot} />}

          {/* Actor avatar with type icon badge */}
          <View style={styles.avatarWrap}>
            <Image
              source={{ uri: item.actor?.avatar || `https://i.pravatar.cc/80?u=${item.actorId}` }}
              style={styles.avatar}
            />
            <View style={[styles.typeBadge, { backgroundColor: meta.bg }]}>
              <Feather name={meta.icon as any} size={10} color={meta.color} />
            </View>
          </View>

          {/* Message */}
          <View style={styles.content}>
            <Text style={styles.message} numberOfLines={2}>
              <Text style={styles.actorName}>{item.actor?.displayName || 'Someone'} </Text>
              {formatMessage(item.type, item.message)}
            </Text>
            <Text style={styles.time}>{timeAgo(item.createdAt)}</Text>
          </View>

          {/* Arrow for navigable items */}
          {(item.postId || item.type === 'follow') && (
            <Feather name="chevron-right" size={16} color={Colors.metalSheen} />
          )}
        </TouchableOpacity>
      </>
    );
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <StatusBar barStyle="dark-content" />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Feather name="arrow-left" size={20} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Notifications</Text>
        {unreadCount > 0 && (
          <View style={styles.badge}>
            <Text style={styles.badgeText}>{unreadCount > 99 ? '99+' : unreadCount}</Text>
          </View>
        )}
      </View>

      {loading ? (
        <View style={styles.centered}>
          <ActivityIndicator color={Colors.metalMid} />
        </View>
      ) : notifications.length === 0 ? (
        <EmptyNotifications />
      ) : (
        <FlatList
          data={notifications}
          renderItem={renderNotification}
          keyExtractor={(n) => n.id}
          contentContainerStyle={styles.list}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={Colors.metalMid} />
          }
          showsVerticalScrollIndicator={false}
        />
      )}
    </View>
  );
}

function EmptyNotifications() {
  return (
    <View style={styles.emptyWrap}>
      <View style={styles.emptyIcon}>
        <Feather name="bell" size={32} color={Colors.metalLight} />
      </View>
      <Text style={styles.emptyTitle}>No notifications yet</Text>
      <Text style={styles.emptySubtitle}>
        When someone likes your post, follows you, or you get a deal alert — it'll show up here.
      </Text>
    </View>
  );
}

// ── Helpers ───────────────────────────────────────────────────────────────────
const formatMessage = (type: string, fallback: string): string => {
  const short: Record<string, string> = {
    like:       'liked your post',
    comment:    'commented on your post',
    follow:     'started following you',
    deal_alert: 'found a new deal for you',
    price_drop: 'Price dropped on a saved item',
  };
  return short[type] || fallback;
};

const timeAgo = (iso: string): string => {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return 'just now';
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  if (d < 7) return `${d}d ago`;
  return new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
};

const getDateGroup = (iso: string): string => {
  const diff = Date.now() - new Date(iso).getTime();
  const d = Math.floor(diff / 86400000);
  if (d === 0) return 'Today';
  if (d === 1) return 'Yesterday';
  if (d < 7) return 'This week';
  return 'Earlier';
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: Spacing.base, paddingVertical: Spacing.sm,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
    gap: Spacing.sm,
  },
  backBtn: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: Colors.surfaceSubtle, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: Colors.border,
  },
  headerTitle: {
    flex: 1, fontFamily: 'Playfair-Bold',
    fontSize: Typography.lg, color: Colors.textPrimary,
  },
  badge: {
    backgroundColor: Colors.primary, borderRadius: Radius.full,
    paddingHorizontal: 8, paddingVertical: 2, minWidth: 22, alignItems: 'center',
  },
  badgeText: {
    fontFamily: 'DMSans-Bold', fontSize: 11, color: '#fff',
  },
  list: { paddingTop: Spacing.sm, paddingBottom: Spacing['3xl'] },
  dateHeader: {
    fontFamily: 'DMSans-Bold', fontSize: 11, color: Colors.metalLight,
    textTransform: 'uppercase', letterSpacing: 1.2,
    paddingHorizontal: Spacing.base, paddingTop: Spacing.base, paddingBottom: Spacing.xs,
  },
  row: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: Spacing.base, paddingVertical: Spacing.md,
    gap: Spacing.md, backgroundColor: Colors.background,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  rowUnread: { backgroundColor: Colors.primaryLight },
  unreadDot: {
    position: 'absolute', left: 6, top: '50%',
    width: 6, height: 6, borderRadius: 3, backgroundColor: Colors.primary,
  },
  avatarWrap: { position: 'relative' },
  avatar: {
    width: 46, height: 46, borderRadius: 23,
    backgroundColor: Colors.surface,
  },
  typeBadge: {
    position: 'absolute', bottom: -2, right: -2,
    width: 20, height: 20, borderRadius: 10,
    alignItems: 'center', justifyContent: 'center',
    borderWidth: 2, borderColor: Colors.background,
  },
  content: { flex: 1, gap: 3 },
  message: {
    fontFamily: 'DMSans-Regular', fontSize: Typography.sm,
    color: Colors.textSecondary, lineHeight: 19,
  },
  actorName: { fontFamily: 'DMSans-Bold', color: Colors.textPrimary },
  time: { fontFamily: 'DMSans-Regular', fontSize: 12, color: Colors.metalLight },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  emptyWrap: {
    flex: 1, alignItems: 'center', justifyContent: 'center', padding: Spacing['2xl'],
  },
  emptyIcon: {
    width: 72, height: 72, borderRadius: 36,
    backgroundColor: Colors.surfaceSubtle, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: Colors.border, marginBottom: Spacing.base,
  },
  emptyTitle: {
    fontFamily: 'Playfair-Bold', fontSize: Typography.xl,
    color: Colors.textPrimary, textAlign: 'center', marginBottom: Spacing.sm,
  },
  emptySubtitle: {
    fontFamily: 'DMSans-Regular', fontSize: Typography.base,
    color: Colors.metalMid, textAlign: 'center', lineHeight: 22,
  },
});
