import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import { DocumentSnapshot } from 'firebase/firestore';
import { FeedState, Post } from '../types';
import { fetchDiscoverPosts } from '../services/postService';

// FIX #4: Store the Firestore cursor outside Redux (not serializable)
// Redux can't hold DocumentSnapshot objects — store them in a module-level map
const cursorCache: Record<string, DocumentSnapshot | null> = {
  discover: null,
};

interface FeedStateExtended extends FeedState {
  isLoadingMore: boolean;
}

const initialState: FeedStateExtended = {
  posts: [],
  isLoading: false,
  isRefreshing: false,
  isLoadingMore: false,
  hasMore: true,
  page: 0,
  error: null,
};

// ─── Async Thunks ──────────────────────────────────────────────────────────────

// Initial load — clears cursor
export const loadFeed = createAsyncThunk(
  'feed/loadFeed',
  async (userId: string | undefined, { rejectWithValue }) => {
    try {
      cursorCache.discover = null;
      const { posts, lastDoc } = await fetchDiscoverPosts(userId, undefined);
      cursorCache.discover = lastDoc;
      return posts;
    } catch (err: any) {
      return rejectWithValue(err.message);
    }
  }
);

// Pull-to-refresh — resets cursor + replaces posts
export const refreshFeed = createAsyncThunk(
  'feed/refreshFeed',
  async (userId: string | undefined, { rejectWithValue }) => {
    try {
      cursorCache.discover = null;
      const { posts, lastDoc } = await fetchDiscoverPosts(userId, undefined);
      cursorCache.discover = lastDoc;
      return posts;
    } catch (err: any) {
      return rejectWithValue(err.message);
    }
  }
);

// FIX #4: Load more — uses cursor to append next page
export const loadMoreFeed = createAsyncThunk(
  'feed/loadMoreFeed',
  async (userId: string | undefined, { getState, rejectWithValue }) => {
    const state = (getState() as { feed: FeedStateExtended }).feed;
    // Guard: don't double-fetch
    if (!state.hasMore || state.isLoadingMore) return [];
    try {
      const cursor = cursorCache.discover ?? undefined;
      const { posts, lastDoc } = await fetchDiscoverPosts(userId, cursor);
      cursorCache.discover = lastDoc;
      return posts;
    } catch (err: any) {
      return rejectWithValue(err.message);
    }
  }
);

// ─── Slice ────────────────────────────────────────────────────────────────────

const feedSlice = createSlice({
  name: 'feed',
  initialState,
  reducers: {
    optimisticLike: (state, action: PayloadAction<{ postId: string; userId: string }>) => {
      const post = state.posts.find((p) => p.id === action.payload.postId);
      if (post) {
        post.isLiked = !post.isLiked;
        post.likesCount += post.isLiked ? 1 : -1;
      }
    },
    optimisticSave: (state, action: PayloadAction<{ postId: string; userId: string }>) => {
      const post = state.posts.find((p) => p.id === action.payload.postId);
      if (post) {
        post.isSaved = !post.isSaved;
        post.savesCount += post.isSaved ? 1 : -1;
      }
    },
    addNewPost: (state, action: PayloadAction<Post>) => {
      // Prepend new post, avoid duplicates
      if (!state.posts.find((p) => p.id === action.payload.id)) {
        state.posts.unshift(action.payload);
      }
    },
    removePost: (state, action: PayloadAction<string>) => {
      state.posts = state.posts.filter((p) => p.id !== action.payload);
    },
    updatePostInFeed: (state, action: PayloadAction<Partial<Post> & { id: string }>) => {
      const idx = state.posts.findIndex((p) => p.id === action.payload.id);
      if (idx !== -1) state.posts[idx] = { ...state.posts[idx], ...action.payload };
    },
  },
  extraReducers: (builder) => {
    // loadFeed
    builder
      .addCase(loadFeed.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(loadFeed.fulfilled, (state, action) => {
        state.isLoading = false;
        state.posts = action.payload;
        state.hasMore = action.payload.length === 10;
      })
      .addCase(loadFeed.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      });

    // refreshFeed
    builder
      .addCase(refreshFeed.pending, (state) => { state.isRefreshing = true; })
      .addCase(refreshFeed.fulfilled, (state, action) => {
        state.isRefreshing = false;
        state.posts = action.payload;
        state.hasMore = action.payload.length === 10;
        state.page = 0;
      })
      .addCase(refreshFeed.rejected, (state) => { state.isRefreshing = false; });

    // loadMoreFeed — appends with deduplication
    builder
      .addCase(loadMoreFeed.pending, (state) => { state.isLoadingMore = true; })
      .addCase(loadMoreFeed.fulfilled, (state, action) => {
        state.isLoadingMore = false;
        if (!action.payload?.length) {
          state.hasMore = false;
          return;
        }
        // Deduplicate by ID before appending
        const existingIds = new Set(state.posts.map((p) => p.id));
        const newPosts = action.payload.filter((p) => !existingIds.has(p.id));
        state.posts.push(...newPosts);
        state.hasMore = action.payload.length === 10;
        state.page += 1;
      })
      .addCase(loadMoreFeed.rejected, (state) => { state.isLoadingMore = false; });
  },
});

export const {
  optimisticLike, optimisticSave, addNewPost, removePost, updatePostInFeed,
} = feedSlice.actions;
export default feedSlice.reducer;
