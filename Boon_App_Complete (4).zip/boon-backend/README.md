# Boon Backend API

Node.js + TypeScript REST API for the Boon social shopping app.

## Stack
- **Runtime**: Node.js 20 + TypeScript
- **Framework**: Express.js
- **Database**: PostgreSQL (analytics, deals cache, notifications)
- **Auth**: Firebase Admin SDK (verifies JWT tokens from the mobile app)
- **AI**: OpenAI GPT-4o (Deal Finder chat + deal extraction)
- **Cache**: PostgreSQL (OG metadata + deals)

---

## Quick Start

### Option A — Docker (recommended)
```bash
cp .env.example .env
# Fill in .env with your Firebase and OpenAI credentials

docker-compose up
# API runs at http://localhost:3000
# PostgreSQL at localhost:5432
# Redis at localhost:6379
```

### Option B — Local Node
```bash
cp .env.example .env
npm install

# Requires PostgreSQL running locally:
# createdb boon

npm run dev
# Starts with ts-node-dev hot reload
```

---

## Deploy to Railway (Production)

```bash
npm install -g @railway/cli
railway login
railway init
railway up

# Set environment variables in Railway dashboard:
# FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, FIREBASE_PRIVATE_KEY, OPENAI_API_KEY
```

Railway will auto-provision PostgreSQL and Redis from `railway.toml`.
Your API URL will be: `https://boon-api-production.up.railway.app`

Then update your mobile app's `.env`:
```
EXPO_PUBLIC_API_URL=https://boon-api-production.up.railway.app
```

---

## API Reference

All endpoints are prefixed with `/api`.
Protected routes require: `Authorization: Bearer <firebase-id-token>`

### Health
```
GET  /api/health
```

---

### OG Metadata
```
GET  /api/og?url=https://store.com/product
```
Returns Open Graph metadata (title, description, image) for any URL.
Cached for 24 hours.

**Response:**
```json
{
  "success": true,
  "data": {
    "title": "Nike Air Max 90",
    "description": "Shop the latest...",
    "image": "https://cdn.nike.com/...",
    "siteName": "Nike",
    "url": "https://nike.com/product/123"
  }
}
```

---

### Deals (AI Deal Finder)
```
GET  /api/deals?storeName=Nike&storeUrl=https://nike.com     🔓 optional auth
POST /api/deals/chat                                          🔐 auth required
```

**GET /api/deals** — Find active coupons for a store:
```json
{
  "success": true,
  "data": [
    {
      "source": "RetailMeNot",
      "title": "20% off sitewide",
      "code": "SAVE20",
      "discount": "20%",
      "url": "https://retailmenot.com/view/nike.com",
      "expiresAt": "2024-12-31"
    }
  ],
  "count": 1
}
```

**POST /api/deals/chat** — Streaming AI chat (SSE):
```json
// Request body:
{
  "messages": [
    { "role": "user", "content": "Find me deals for Nike shoes" }
  ]
}
// Response: text/event-stream
// data: {"chunk": "Sure! "}
// data: {"chunk": "I found "}
// data: [DONE]
```

---

### Feed
```
GET  /api/posts/feed?limit=10&cursor=postId     🔐 auth required
GET  /api/posts/discover?limit=10&cursor=postId 🔓 optional auth
```

**Response:**
```json
{
  "success": true,
  "data": [...posts],
  "hasMore": true,
  "nextCursor": "post_id_xyz"
}
```

---

### Post Actions
```
POST /api/posts/:id/like          🔐 Toggle like
POST /api/posts/:id/save          🔐 Toggle save to wishlist
GET  /api/posts/:id/comments      🔓 Get comments
POST /api/posts/:id/comments      🔐 Add comment { "text": "..." }
POST /api/posts/:id/track-click   🔓 Track store URL click (CTR)
```

---

### Users
```
GET   /api/users/search?q=username    🔓 Search users by username
GET   /api/users/:id                  🔓 Get user profile
PATCH /api/users/:id                  🔐 Update own profile
POST  /api/users/:id/follow           🔐 Follow / unfollow
```

**PATCH /api/users/:id body:**
```json
{
  "displayName": "Jane Doe",
  "username": "janedoe",
  "bio": "Fashion lover 🛍️",
  "avatar": "https://storage.google.com/..."
}
```

---

### Notifications
```
GET  /api/notifications?limit=30&offset=0   🔐
POST /api/notifications/read                🔐  { "ids": ["id1","id2"] } or {} for all
```

---

### Analytics (KPIs from PRD)
```
GET  /api/analytics/dashboard   🔐 DAU, CTR, Deal Finder usage, top stores
POST /api/analytics/track       🔓 Track any event
```

**POST /api/analytics/track body:**
```json
{
  "eventType": "store_url_click",
  "postId": "abc123",
  "storeUrl": "https://nike.com"
}
```

**Event types:** `store_url_click`, `post_view`, `deal_finder_query`, `post_create`, `follow`, `app_open`

---

## Project Structure

```
src/
├── server.ts              # Express app entry point
├── config/
│   ├── firebase.ts        # Firebase Admin SDK
│   └── database.ts        # PostgreSQL pool + migrations
├── middleware/
│   ├── auth.ts            # JWT verification
│   └── errorHandler.ts    # Global error handling
├── routes/
│   └── index.ts           # All routes wired together
├── controllers/
│   ├── ogController.ts
│   ├── dealController.ts
│   ├── postController.ts
│   ├── userController.ts
│   ├── notificationController.ts
│   └── analyticsController.ts
└── services/
    ├── ogService.ts           # OG scraper + cache
    ├── dealService.ts         # Coupon scraper + GPT-4o
    ├── notificationService.ts # Notification CRUD
    └── analyticsService.ts    # KPI tracking queries
```

---

## Rate Limits
| Endpoint group | Limit |
|---|---|
| Standard API | 100 req/min |
| AI Deal Finder | 20 req/min |
| OG Metadata | 50 req/min |

---

## Environment Variables
See `.env.example` for the full list.
