import OpenAI from 'openai';
import axios from 'axios';
import { getPool } from '../config/database';

export interface Deal {
  source: string;
  title: string;
  url: string;
  discount?: string;
  originalPrice?: string;
  salePrice?: string;
  code?: string;
  expiresAt?: string;
}

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const CACHE_TTL_HOURS = 6;

// ── Main Deal Finder ──────────────────────────────────────────────────────────
export const findDeals = async (
  storeName: string,
  storeUrl: string
): Promise<Deal[]> => {
  const db = getPool();
  const cacheKey = storeUrl.toLowerCase();

  // 1. Check DB cache
  const cached = await db.query(
    `SELECT deals FROM deal_cache
     WHERE store_url = $1 AND expires_at > NOW()
     ORDER BY fetched_at DESC LIMIT 1`,
    [cacheKey]
  );

  if (cached.rows.length > 0) {
    return cached.rows[0].deals as Deal[];
  }

  // 2. Fetch fresh deals
  const deals = await fetchFreshDeals(storeName, storeUrl);

  // 3. Cache results
  await db.query(
    `INSERT INTO deal_cache (store_url, store_name, deals, expires_at)
     VALUES ($1, $2, $3, NOW() + INTERVAL '${CACHE_TTL_HOURS} hours')`,
    [cacheKey, storeName, JSON.stringify(deals)]
  );

  return deals;
};

// ── Fetch from Multiple Sources ───────────────────────────────────────────────
const fetchFreshDeals = async (
  storeName: string,
  storeUrl: string
): Promise<Deal[]> => {
  const domain = extractDomain(storeUrl);
  const results = await Promise.allSettled([
    scrapeRetailMeNot(domain),
    scrapeHoneyDeals(domain),
    useAIToFindDeals(storeName, storeUrl),
  ]);

  const allDeals: Deal[] = [];
  for (const result of results) {
    if (result.status === 'fulfilled' && Array.isArray(result.value)) {
      allDeals.push(...result.value);
    }
  }

  // Deduplicate by coupon code
  const seen = new Set<string>();
  return allDeals.filter((d) => {
    const key = d.code || d.title;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
};

// ── RetailMeNot Scraper ───────────────────────────────────────────────────────
const scrapeRetailMeNot = async (domain: string): Promise<Deal[]> => {
  try {
    const url = `https://www.retailmenot.com/view/${domain}`;
    const res = await axios.get(url, {
      timeout: 6000,
      headers: { 'User-Agent': 'Mozilla/5.0 (compatible; BoonBot/1.0)' },
    });

    const deals: Deal[] = [];
    // Basic regex extraction for coupon codes
    const codeMatches = res.data.match(/data-code="([A-Z0-9]{4,20})"/g) || [];
    const titleMatches = res.data.match(/"offer-title[^"]*">[^<]{5,80}</g) || [];

    for (let i = 0; i < Math.min(codeMatches.length, 5); i++) {
      const code = codeMatches[i]?.match(/data-code="([^"]+)"/)?.[1];
      const title = titleMatches[i]?.replace(/^[^>]+>/, '').trim() || `Deal at ${domain}`;
      if (code) {
        deals.push({
          source: 'RetailMeNot',
          title,
          code,
          url: `https://www.retailmenot.com/view/${domain}`,
        });
      }
    }
    return deals;
  } catch {
    return [];
  }
};

// ── Honey/Deals Fallback ──────────────────────────────────────────────────────
const scrapeHoneyDeals = async (domain: string): Promise<Deal[]> => {
  try {
    // Use Honey's public deals API endpoint
    const res = await axios.get(
      `https://api.joinhoney.com/api/deals/search?domain=${domain}`,
      { timeout: 5000 }
    );
    const items = res.data?.results?.slice(0, 5) || [];
    return items.map((item: any) => ({
      source: 'Honey',
      title: item.title || 'Deal available',
      code: item.code,
      discount: item.discount_string,
      url: item.url || `https://joinhoney.com/store/${domain}`,
      expiresAt: item.expires_at,
    }));
  } catch {
    return [];
  }
};

// ── AI Deal Finder (GPT-4o with web search) ───────────────────────────────────
const useAIToFindDeals = async (
  storeName: string,
  storeUrl: string
): Promise<Deal[]> => {
  try {
    const completion = await openai.chat.completions.create({
      model: 'gpt-4o',
      max_tokens: 800,
      messages: [
        {
          role: 'system',
          content: `You are a coupon finder. Search your knowledge for active coupon codes and deals for the given store.
Return ONLY a JSON array of deals. No other text.
Format: [{"source":"string","title":"string","code":"string|null","discount":"string|null","url":"string","expiresAt":"YYYY-MM-DD|null"}]
If you don't know of any deals, return an empty array [].`,
        },
        {
          role: 'user',
          content: `Find current coupon codes and deals for: ${storeName} (${storeUrl})`,
        },
      ],
    });

    const text = completion.choices[0]?.message?.content || '[]';
    const jsonMatch = text.match(/\[[\s\S]*\]/);
    if (!jsonMatch) return [];

    const deals = JSON.parse(jsonMatch[0]) as Deal[];
    return deals.map((d) => ({ ...d, source: d.source || 'AI Deal Finder' }));
  } catch {
    return [];
  }
};

// ── AI Chat Streaming ─────────────────────────────────────────────────────────
export const streamDealChat = async (
  messages: { role: 'user' | 'assistant'; content: string }[],
  onChunk: (chunk: string) => void
): Promise<void> => {
  const stream = await openai.chat.completions.create({
    model: 'gpt-4o',
    stream: true,
    max_tokens: 1000,
    messages: [
      {
        role: 'system',
        content: `You are Boon's AI Deal Finder — a savvy, friendly shopping assistant.
Help users find coupon codes, compare prices, and discover the best deals.
When you find deals, format them clearly. Be concise and enthusiastic. Use emojis sparingly.`,
      },
      ...messages,
    ],
  });

  for await (const chunk of stream) {
    const delta = chunk.choices[0]?.delta?.content || '';
    if (delta) onChunk(delta);
  }
};

// ── Helpers ───────────────────────────────────────────────────────────────────
const extractDomain = (url: string): string => {
  try {
    return new URL(url).hostname.replace('www.', '');
  } catch {
    return url;
  }
};
