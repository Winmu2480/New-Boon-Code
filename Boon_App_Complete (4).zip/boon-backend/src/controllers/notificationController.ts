import { Response, NextFunction } from 'express';
import { AuthRequest } from '../middleware/auth';
import {
  getUserNotifications,
  markNotificationsRead,
  getUnreadCount,
} from '../services/notificationService';

// GET /api/notifications
export const getNotifications = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const userId = req.user!.uid;
    const limit = parseInt(req.query.limit as string) || 30;
    const offset = parseInt(req.query.offset as string) || 0;

    const [notifications, unread] = await Promise.all([
      getUserNotifications(userId, limit, offset),
      getUnreadCount(userId),
    ]);

    res.json({ success: true, data: notifications, unreadCount: unread });
  } catch (err) {
    next(err);
  }
};

// POST /api/notifications/read
export const markRead = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const userId = req.user!.uid;
    const ids: string[] | undefined = req.body.ids;
    await markNotificationsRead(userId, ids);
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
};
