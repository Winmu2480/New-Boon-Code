import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { requireAuth, optionalAuth } from '../middleware/auth';

// Controllers
import { getOGMetadata } from '../controllers/ogController';
import { getDeals, chatWithDeals } from '../controllers/dealController';
import { getUser, updateUser, followUser, searchUsers } from '../controllers/userController';
import {
  getFeed, getDiscover, likePost, savePost,
  getComments, addComment, trackStoreClick,
} from '../controllers/postController';
import { getNotifications, markRead } from '../controllers/notificationController';
import { getDashboard, track } from '../controllers/analyticsController';

const router = Router();

// ── Rate Limiters ─────────────────────────────────────────────────────────────
const standardLimit = rateLimit({ windowMs: 60_000, max: 100 }); // 100/min
const aiLimit = rateLimit({ windowMs: 60_000, max: 20 });         // 20/min (AI is expensive)
const ogLimit = rateLimit({ windowMs: 60_000, max: 50 });         // 50/min

// ── Health ────────────────────────────────────────────────────────────────────
router.get('/health', (_, res) => res.json({ status: 'ok', version: '1.0.0' }));

// ── OG Metadata ───────────────────────────────────────────────────────────────
router.get('/og', ogLimit, getOGMetadata);

// ── Deals (AI Deal Finder) ────────────────────────────────────────────────────
router.get('/deals', aiLimit, optionalAuth, getDeals);
router.post('/deals/chat', aiLimit, requireAuth, chatWithDeals);

// ── Feed ──────────────────────────────────────────────────────────────────────
router.get('/posts/feed', standardLimit, requireAuth, getFeed);
router.get('/posts/discover', standardLimit, optionalAuth, getDiscover);
router.post('/posts/:id/like', standardLimit, requireAuth, likePost);
router.post('/posts/:id/save', standardLimit, requireAuth, savePost);
router.get('/posts/:id/comments', standardLimit, getComments);
router.post('/posts/:id/comments', standardLimit, requireAuth, addComment);
router.post('/posts/:id/track-click', standardLimit, optionalAuth, trackStoreClick);

// ── Users ─────────────────────────────────────────────────────────────────────
router.get('/users/search', standardLimit, searchUsers);
router.get('/users/:id', standardLimit, getUser);
router.patch('/users/:id', standardLimit, requireAuth, updateUser);
router.post('/users/:id/follow', standardLimit, requireAuth, followUser);

// ── Notifications ─────────────────────────────────────────────────────────────
router.get('/notifications', standardLimit, requireAuth, getNotifications);
router.post('/notifications/read', standardLimit, requireAuth, markRead);

// ── Analytics ─────────────────────────────────────────────────────────────────
router.get('/analytics/dashboard', requireAuth, getDashboard); // Admin only
router.post('/analytics/track', standardLimit, optionalAuth, track);

export default router;
