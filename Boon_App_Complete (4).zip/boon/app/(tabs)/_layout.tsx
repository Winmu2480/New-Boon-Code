import { Tabs } from 'expo-router';
import { View, StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Colors } from '../../constants/theme';
import { Feather } from '@expo/vector-icons';

function TabIcon({ name, focused }: { name: any; focused: boolean }) {
  return (
    <View style={[styles.icon, focused && styles.iconActive]}>
      <Feather name={name} size={21} color={focused ? Colors.textPrimary : Colors.metalLight} />
    </View>
  );
}

function CreateIcon() {
  return (
    <View style={styles.createBtn}>
      <Feather name="plus" size={20} color="#fff" />
    </View>
  );
}

export default function TabsLayout() {
  const insets = useSafeAreaInsets();
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarShowLabel: false,
        tabBarStyle: {
          backgroundColor: Colors.background,
          borderTopWidth: 1,
          borderTopColor: Colors.border,
          height: 56 + insets.bottom,
          paddingBottom: insets.bottom,
          elevation: 0,
          shadowColor: '#000',
          shadowOpacity: 0.04,
          shadowOffset: { width: 0, height: -2 },
          shadowRadius: 8,
        },
      }}
    >
      <Tabs.Screen name="index"         options={{ tabBarIcon: ({ focused }) => <TabIcon name="home"      focused={focused} /> }} />
      <Tabs.Screen name="search"        options={{ tabBarIcon: ({ focused }) => <TabIcon name="search"    focused={focused} /> }} />
      <Tabs.Screen name="create"        options={{ tabBarIcon: () => <CreateIcon /> }} />
      <Tabs.Screen name="deals"         options={{ tabBarIcon: ({ focused }) => <TabIcon name="zap"       focused={focused} /> }} />
      <Tabs.Screen name="notifications" options={{ tabBarIcon: ({ focused }) => <TabIcon name="bell"      focused={focused} /> }} />
      <Tabs.Screen name="profile"       options={{ tabBarIcon: ({ focused }) => <TabIcon name="user"      focused={focused} /> }} />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  icon: {
    width: 40, height: 36, borderRadius: 10,
    alignItems: 'center', justifyContent: 'center',
  },
  iconActive: { backgroundColor: Colors.surfaceMid },
  createBtn: {
    width: 44, height: 44, borderRadius: 14,
    backgroundColor: Colors.textPrimary,
    alignItems: 'center', justifyContent: 'center',
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2, shadowRadius: 8, elevation: 5,
  },
});
