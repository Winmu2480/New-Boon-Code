import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity,
  KeyboardAvoidingView, Platform, ScrollView,
  ActivityIndicator, Alert, StatusBar,
} from 'react-native';
import { router } from 'expo-router';
import { useDispatch, useSelector } from 'react-redux';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import Animated, { FadeInDown, FadeInUp } from 'react-native-reanimated';
import * as AppleAuthentication from 'expo-apple-authentication';
import { GoogleSignin, GoogleSigninButton, statusCodes } from '@react-native-google-signin/google-signin';
import { Colors, Typography, Spacing, Radius, Shadow } from '../../constants/theme';
import { loginWithEmail, loginWithSocial, clearError } from '../../store/authSlice';
import { signInWithApple, signInWithGoogleToken } from '../../services/authService';
import { getUserDocument } from '../../services/authService';
import { AppDispatch, RootState } from '../../store';
import { setUser } from '../../store/authSlice';
import { auth } from '../../services/firebase';

// 🔑 Add your webClientId from Google Cloud Console to .env:
// EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID=your_web_client_id
GoogleSignin.configure({
  webClientId: process.env.EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID || '',
  offlineAccess: false,
});

export default function LoginScreen() {
  const dispatch = useDispatch<AppDispatch>();
  const insets = useSafeAreaInsets();
  const { isLoading, error } = useSelector((s: RootState) => s.auth);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [focused, setFocused] = useState<string | null>(null);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [appleLoading, setAppleLoading] = useState(false);
  const [appleAvailable, setAppleAvailable] = useState(false);

  useEffect(() => {
    // Apple Sign-In only available on iOS 13+
    AppleAuthentication.isAvailableAsync().then(setAppleAvailable);
  }, []);

  const handleLogin = async () => {
    if (!email.trim() || !password) {
      Alert.alert('Missing fields', 'Please enter your email and password.');
      return;
    }
    const result = await dispatch(loginWithEmail({ email: email.trim(), password }));
    if (loginWithEmail.fulfilled.match(result)) router.replace('/(tabs)');
  };

  // ── FIX #1: Google Sign-In ──────────────────────────────────────────────────
  const handleGoogleSignIn = async () => {
    setGoogleLoading(true);
    try {
      await GoogleSignin.hasPlayServices();
      const userInfo = await GoogleSignin.signIn();
      const idToken = userInfo.data?.idToken;
      if (!idToken) throw new Error('No ID token from Google');

      const fbUser = await signInWithGoogleToken(idToken);
      const userDoc = await getUserDocument(fbUser.uid);
      const token = await fbUser.getIdToken();
      if (userDoc) {
        dispatch(setUser({ user: userDoc, token }));
        router.replace('/(tabs)');
      }
    } catch (err: any) {
      if (err.code === statusCodes.SIGN_IN_CANCELLED) return;
      if (err.code === statusCodes.IN_PROGRESS) return;
      Alert.alert('Google Sign-In failed', err.message || 'Please try again.');
    } finally {
      setGoogleLoading(false);
    }
  };

  // ── FIX #2: Apple Sign-In ───────────────────────────────────────────────────
  const handleAppleSignIn = async () => {
    setAppleLoading(true);
    try {
      const fbUser = await signInWithApple();
      const userDoc = await getUserDocument(fbUser.uid);
      const token = await fbUser.getIdToken();
      if (userDoc) {
        dispatch(setUser({ user: userDoc, token }));
        router.replace('/(tabs)');
      }
    } catch (err: any) {
      if (err.code === 'ERR_REQUEST_CANCELED') return; // User dismissed
      Alert.alert('Apple Sign-In failed', err.message || 'Please try again.');
    } finally {
      setAppleLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <StatusBar barStyle="dark-content" />
      <ScrollView
        contentContainerStyle={[styles.scroll, { paddingTop: insets.top + 24, paddingBottom: insets.bottom + 40 }]}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* Logo */}
        <Animated.View entering={FadeInDown.delay(0).duration(480)} style={styles.logoSection}>
          <View style={styles.logoMark}>
            <Text style={styles.logoMarkLetter}>B</Text>
          </View>
          <Text style={styles.logoWord}>boon</Text>
          <Text style={styles.tagline}>DISCOVER · SHARE · SHOP</Text>
        </Animated.View>

        {/* Card */}
        <Animated.View entering={FadeInDown.delay(100).duration(480)} style={styles.card}>
          <Text style={styles.cardTitle}>Welcome back</Text>
          <Text style={styles.cardSubtitle}>Sign in to continue</Text>

          {error && (
            <View style={styles.errorBanner}>
              <Feather name="alert-circle" size={14} color={Colors.error} />
              <Text style={styles.errorText}>{error}</Text>
              <TouchableOpacity onPress={() => dispatch(clearError())}>
                <Feather name="x" size={14} color={Colors.error} />
              </TouchableOpacity>
            </View>
          )}

          {/* Email */}
          <View style={styles.field}>
            <Text style={styles.label}>Email address</Text>
            <View style={[styles.inputWrap, focused === 'email' && styles.inputActive]}>
              <Feather name="mail" size={16} color={focused === 'email' ? Colors.textPrimary : Colors.metalLight} />
              <TextInput
                style={styles.input}
                placeholder="you@example.com"
                placeholderTextColor={Colors.textFaint}
                value={email}
                onChangeText={setEmail}
                onFocus={() => setFocused('email')}
                onBlur={() => setFocused(null)}
                keyboardType="email-address"
                autoCapitalize="none"
                autoCorrect={false}
                returnKeyType="next"
              />
            </View>
          </View>

          {/* Password */}
          <View style={styles.field}>
            <View style={styles.labelRow}>
              <Text style={styles.label}>Password</Text>
              <TouchableOpacity onPress={() => router.push('/(auth)/forgot-password')}>
                <Text style={styles.forgotText}>Forgot password?</Text>
              </TouchableOpacity>
            </View>
            <View style={[styles.inputWrap, focused === 'password' && styles.inputActive]}>
              <Feather name="lock" size={16} color={focused === 'password' ? Colors.textPrimary : Colors.metalLight} />
              <TextInput
                style={styles.input}
                placeholder="••••••••"
                placeholderTextColor={Colors.textFaint}
                value={password}
                onChangeText={setPassword}
                onFocus={() => setFocused('password')}
                onBlur={() => setFocused(null)}
                secureTextEntry={!showPassword}
                returnKeyType="done"
                onSubmitEditing={handleLogin}
              />
              <TouchableOpacity onPress={() => setShowPassword(!showPassword)} style={styles.eye}>
                <Feather name={showPassword ? 'eye-off' : 'eye'} size={16} color={Colors.metalMid} />
              </TouchableOpacity>
            </View>
          </View>

          {/* Sign In */}
          <TouchableOpacity
            style={[styles.cta, isLoading && styles.ctaDisabled]}
            onPress={handleLogin}
            disabled={isLoading}
            activeOpacity={0.85}
          >
            {isLoading
              ? <ActivityIndicator color="#fff" />
              : <Text style={styles.ctaText}>Sign In</Text>
            }
          </TouchableOpacity>

          {/* Divider */}
          <View style={styles.divider}>
            <View style={styles.divLine} />
            <Text style={styles.divLabel}>or continue with</Text>
            <View style={styles.divLine} />
          </View>

          {/* Social buttons */}
          <View style={styles.socials}>
            {/* Google */}
            <TouchableOpacity
              style={styles.socialBtn}
              onPress={handleGoogleSignIn}
              disabled={googleLoading}
              activeOpacity={0.8}
            >
              {googleLoading
                ? <ActivityIndicator size="small" color={Colors.textSecondary} />
                : <>
                    <Feather name="globe" size={17} color={Colors.textSecondary} />
                    <Text style={styles.socialLabel}>Google</Text>
                  </>
              }
            </TouchableOpacity>

            {/* Apple — only show on iOS 13+ */}
            {appleAvailable
              ? (
                <TouchableOpacity
                  style={styles.socialBtn}
                  onPress={handleAppleSignIn}
                  disabled={appleLoading}
                  activeOpacity={0.8}
                >
                  {appleLoading
                    ? <ActivityIndicator size="small" color={Colors.textSecondary} />
                    : <>
                        <Feather name="smartphone" size={17} color={Colors.textSecondary} />
                        <Text style={styles.socialLabel}>Apple</Text>
                      </>
                  }
                </TouchableOpacity>
              )
              : (
                // Show disabled Apple button on Android
                <View style={[styles.socialBtn, { opacity: 0.35 }]}>
                  <Feather name="smartphone" size={17} color={Colors.textSecondary} />
                  <Text style={styles.socialLabel}>Apple</Text>
                </View>
              )
            }
          </View>
        </Animated.View>

        {/* Footer */}
        <Animated.View entering={FadeInUp.delay(200).duration(480)} style={styles.footer}>
          <Text style={styles.footerText}>Don't have an account?</Text>
          <TouchableOpacity onPress={() => router.push('/(auth)/register')}>
            <Text style={styles.footerCta}> Create account</Text>
          </TouchableOpacity>
        </Animated.View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  scroll: { flexGrow: 1, paddingHorizontal: Spacing.xl },

  logoSection: { alignItems: 'center', marginBottom: 32 },
  logoMark: {
    width: 60, height: 60, borderRadius: 18,
    backgroundColor: Colors.textPrimary,
    alignItems: 'center', justifyContent: 'center',
    marginBottom: 10, ...Shadow.strong,
  },
  logoMarkLetter: { fontFamily: 'Playfair-Bold', fontSize: 28, color: '#fff' },
  logoWord: { fontFamily: 'Playfair-Bold', fontSize: 30, color: Colors.textPrimary, letterSpacing: -0.8 },
  tagline: { fontFamily: 'DMSans-Regular', fontSize: 10, color: Colors.metalLight, marginTop: 4, letterSpacing: 2.2 },

  card: {
    backgroundColor: Colors.surfaceSubtle, borderRadius: Radius.xl,
    padding: Spacing.xl, gap: Spacing.base,
    borderWidth: 1, borderColor: Colors.border, ...Shadow.card,
  },
  cardTitle: { fontFamily: 'Playfair-Bold', fontSize: Typography.xl, color: Colors.textPrimary },
  cardSubtitle: { fontFamily: 'DMSans-Regular', fontSize: Typography.sm, color: Colors.metalMid, marginTop: -6 },

  errorBanner: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: Colors.errorLight, borderRadius: Radius.sm,
    padding: Spacing.md, borderWidth: 1, borderColor: Colors.error + '25',
  },
  errorText: { flex: 1, fontFamily: 'DMSans-Regular', fontSize: Typography.sm, color: Colors.error },

  field: { gap: 6 },
  label: { fontFamily: 'DMSans-Medium', fontSize: 13, color: Colors.textSecondary },
  labelRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  forgotText: { fontFamily: 'DMSans-Medium', fontSize: 13, color: Colors.metalMid },
  inputWrap: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    backgroundColor: Colors.background, borderRadius: Radius.md,
    borderWidth: 1.5, borderColor: Colors.border,
    paddingHorizontal: Spacing.base, height: 52,
  },
  inputActive: { borderColor: Colors.textPrimary },
  input: { flex: 1, fontFamily: 'DMSans-Regular', fontSize: Typography.base, color: Colors.textPrimary },
  eye: { padding: 2 },

  cta: {
    height: 52, borderRadius: Radius.md, backgroundColor: Colors.textPrimary,
    alignItems: 'center', justifyContent: 'center', marginTop: 4,
    shadowColor: '#000', shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.18, shadowRadius: 10, elevation: 5,
  },
  ctaDisabled: { opacity: 0.5 },
  ctaText: { fontFamily: 'DMSans-Bold', fontSize: Typography.md, color: '#fff', letterSpacing: 0.2 },

  divider: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  divLine: { flex: 1, height: 1, backgroundColor: Colors.border },
  divLabel: { fontFamily: 'DMSans-Regular', fontSize: 12, color: Colors.metalLight },

  socials: { flexDirection: 'row', gap: Spacing.sm },
  socialBtn: {
    flex: 1, height: 48, borderRadius: Radius.md,
    borderWidth: 1.5, borderColor: Colors.border,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    backgroundColor: Colors.background,
  },
  socialLabel: { fontFamily: 'DMSans-Medium', fontSize: Typography.sm, color: Colors.textSecondary },

  footer: { flexDirection: 'row', justifyContent: 'center', marginTop: Spacing.xl },
  footerText: { fontFamily: 'DMSans-Regular', fontSize: Typography.sm, color: Colors.metalMid },
  footerCta: { fontFamily: 'DMSans-Bold', fontSize: Typography.sm, color: Colors.textPrimary },
});
