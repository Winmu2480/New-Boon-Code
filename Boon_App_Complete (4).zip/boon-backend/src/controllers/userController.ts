import { Request, Response, NextFunction } from 'express';
import { z } from 'zod';
import { getFirestore } from '../config/firebase';
import { AuthRequest } from '../middleware/auth';
import { createNotification } from '../services/notificationService';

const UpdateProfileSchema = z.object({
  displayName: z.string().min(1).max(50).optional(),
  username: z.string().min(3).max(30).regex(/^[a-z0-9_]+$/).optional(),
  bio: z.string().max(160).optional(),
  avatar: z.string().url().optional(),
});

// GET /api/users/:id
export const getUser = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { id } = req.params;
    const db = getFirestore();
    const snap = await db.collection('users').doc(id).get();

    if (!snap.exists) {
      res.status(404).json({ error: 'User not found' });
      return;
    }

    // Strip sensitive fields
    const data = snap.data()!;
    delete data.email;

    res.json({ success: true, data: { id: snap.id, ...data } });
  } catch (err) {
    next(err);
  }
};

// PATCH /api/users/:id
export const updateUser = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { id } = req.params;

    // Only allow updating own profile
    if (req.user?.uid !== id) {
      res.status(403).json({ error: 'Forbidden' });
      return;
    }

    const updates = UpdateProfileSchema.parse(req.body);

    // Check username uniqueness if changing
    if (updates.username) {
      const db = getFirestore();
      const existing = await db
        .collection('users')
        .where('username', '==', updates.username)
        .limit(1)
        .get();

      if (!existing.empty && existing.docs[0].id !== id) {
        res.status(409).json({ error: 'Username already taken' });
        return;
      }
    }

    const db = getFirestore();
    await db.collection('users').doc(id).update({
      ...updates,
      updatedAt: new Date().toISOString(),
    });

    res.json({ success: true, message: 'Profile updated' });
  } catch (err) {
    next(err);
  }
};

// POST /api/users/:id/follow
export const followUser = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const targetId = req.params.id;
    const currentUserId = req.user!.uid;

    if (targetId === currentUserId) {
      res.status(400).json({ error: 'Cannot follow yourself' });
      return;
    }

    const db = getFirestore();
    const batch = db.batch();

    // Add to target's followers
    const targetRef = db.collection('users').doc(targetId);
    const currentRef = db.collection('users').doc(currentUserId);

    const [targetSnap, currentSnap] = await Promise.all([
      targetRef.get(),
      currentRef.get(),
    ]);

    if (!targetSnap.exists) {
      res.status(404).json({ error: 'User not found' });
      return;
    }

    const targetData = targetSnap.data()!;
    const currentData = currentSnap.data()!;
    const isFollowing = (targetData.followers || []).includes(currentUserId);

    if (isFollowing) {
      // Unfollow
      batch.update(targetRef, {
        followersCount: Math.max(0, (targetData.followersCount || 1) - 1),
        followers: (targetData.followers || []).filter((id: string) => id !== currentUserId),
      });
      batch.update(currentRef, {
        followingCount: Math.max(0, (currentData.followingCount || 1) - 1),
        following: (currentData.following || []).filter((id: string) => id !== targetId),
      });
    } else {
      // Follow
      batch.update(targetRef, {
        followersCount: (targetData.followersCount || 0) + 1,
        followers: [...(targetData.followers || []), currentUserId],
      });
      batch.update(currentRef, {
        followingCount: (currentData.followingCount || 0) + 1,
        following: [...(currentData.following || []), targetId],
      });

      // Create notification
      await createNotification({
        userId: targetId,
        type: 'follow',
        actorId: currentUserId,
        message: `${currentData.displayName || 'Someone'} started following you`,
      });
    }

    await batch.commit();
    res.json({ success: true, isFollowing: !isFollowing });
  } catch (err) {
    next(err);
  }
};

// GET /api/users/search?q=username
export const searchUsers = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const q = (req.query.q as string)?.toLowerCase().trim();
    if (!q || q.length < 2) {
      res.json({ success: true, data: [] });
      return;
    }

    const db = getFirestore();
    const snap = await db
      .collection('users')
      .orderBy('username')
      .startAt(q)
      .endAt(q + '\uf8ff')
      .limit(20)
      .get();

    const users = snap.docs.map((d) => {
      const data = d.data();
      delete data.email;
      return { id: d.id, ...data };
    });

    res.json({ success: true, data: users });
  } catch (err) {
    next(err);
  }
};
