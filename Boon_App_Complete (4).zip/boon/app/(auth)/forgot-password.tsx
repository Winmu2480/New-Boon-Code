import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity,
  KeyboardAvoidingView, Platform, ScrollView,
  ActivityIndicator, StatusBar,
} from 'react-native';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { sendPasswordResetEmail } from 'firebase/auth';
import { auth } from '../../services/firebase';
import { Colors, Typography, Spacing, Radius, Shadow } from '../../constants/theme';

type Step = 'enter' | 'sent';

export default function ForgotPasswordScreen() {
  const insets = useSafeAreaInsets();
  const [email, setEmail] = useState('');
  const [step, setStep] = useState<Step>('enter');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [focused, setFocused] = useState(false);

  const handleSend = async () => {
    if (!email.trim()) { setError('Please enter your email address.'); return; }
    setLoading(true);
    setError('');
    try {
      await sendPasswordResetEmail(auth, email.trim());
      setStep('sent');
    } catch (err: any) {
      const msg = err.code === 'auth/user-not-found'
        ? 'No account found with this email.'
        : err.code === 'auth/invalid-email'
        ? 'Please enter a valid email address.'
        : 'Something went wrong. Please try again.';
      setError(msg);
    }
    setLoading(false);
  };

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <StatusBar barStyle="dark-content" />
      <View style={[styles.topBar, { paddingTop: insets.top + 8 }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Feather name="arrow-left" size={22} color={Colors.textPrimary} />
        </TouchableOpacity>
      </View>

      <ScrollView
        contentContainerStyle={[styles.scroll, { paddingBottom: insets.bottom + 40 }]}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {step === 'enter' ? (
          <Animated.View entering={FadeInDown.duration(400)} style={styles.content}>
            <View style={styles.iconCircle}>
              <Feather name="lock" size={26} color={Colors.textPrimary} />
            </View>
            <Text style={styles.title}>Forgot password?</Text>
            <Text style={styles.subtitle}>
              No worries. Enter your email and we'll send you a reset link.
            </Text>

            <View style={styles.field}>
              <Text style={styles.label}>Email address</Text>
              <View style={[styles.inputWrap, focused && styles.inputActive]}>
                <Feather name="mail" size={16} color={focused ? Colors.textPrimary : Colors.metalLight} />
                <TextInput
                  style={styles.input}
                  placeholder="you@example.com"
                  placeholderTextColor={Colors.textFaint}
                  value={email}
                  onChangeText={(t) => { setEmail(t); setError(''); }}
                  onFocus={() => setFocused(true)}
                  onBlur={() => setFocused(false)}
                  keyboardType="email-address"
                  autoCapitalize="none"
                  autoCorrect={false}
                  returnKeyType="send"
                  onSubmitEditing={handleSend}
                />
              </View>
              {error ? <Text style={styles.errorText}>{error}</Text> : null}
            </View>

            <TouchableOpacity
              style={[styles.cta, loading && styles.ctaDisabled]}
              onPress={handleSend}
              disabled={loading}
              activeOpacity={0.85}
            >
              {loading
                ? <ActivityIndicator color="#fff" />
                : <Text style={styles.ctaText}>Send Reset Link</Text>
              }
            </TouchableOpacity>

            <TouchableOpacity onPress={() => router.push('/(auth)/login')} style={styles.backToLogin}>
              <Feather name="arrow-left" size={14} color={Colors.metalMid} />
              <Text style={styles.backToLoginText}>Back to sign in</Text>
            </TouchableOpacity>
          </Animated.View>
        ) : (
          <Animated.View entering={FadeInDown.duration(400)} style={styles.content}>
            <View style={[styles.iconCircle, styles.iconSuccess]}>
              <Feather name="check" size={26} color={Colors.success} />
            </View>
            <Text style={styles.title}>Check your inbox</Text>
            <Text style={styles.subtitle}>
              We sent a password reset link to{'\n'}
              <Text style={styles.emailHighlight}>{email}</Text>
            </Text>
            <Text style={styles.note}>
              Didn't receive it? Check your spam folder, or{' '}
              <Text style={styles.resendLink} onPress={() => setStep('enter')}>try again</Text>.
            </Text>
            <TouchableOpacity style={styles.cta} onPress={() => router.replace('/(auth)/login')} activeOpacity={0.85}>
              <Text style={styles.ctaText}>Back to Sign In</Text>
            </TouchableOpacity>
          </Animated.View>
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  topBar: { paddingHorizontal: Spacing.base, paddingBottom: Spacing.sm },
  backBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: Colors.surface, alignItems: 'center', justifyContent: 'center' },
  scroll: { flexGrow: 1, paddingHorizontal: Spacing.xl },
  content: { gap: Spacing.base, paddingTop: Spacing.xl },

  iconCircle: {
    width: 70, height: 70, borderRadius: 35,
    backgroundColor: Colors.surface, alignItems: 'center', justifyContent: 'center',
    alignSelf: 'center', marginBottom: Spacing.sm,
    borderWidth: 1, borderColor: Colors.border,
  },
  iconSuccess: { backgroundColor: Colors.successLight, borderColor: Colors.success + '30' },

  title: { fontFamily: 'Playfair-Bold', fontSize: Typography['2xl'], color: Colors.textPrimary, textAlign: 'center' },
  subtitle: { fontFamily: 'DMSans-Regular', fontSize: Typography.base, color: Colors.metalMid, textAlign: 'center', lineHeight: 22 },
  emailHighlight: { fontFamily: 'DMSans-Bold', color: Colors.textPrimary },
  note: { fontFamily: 'DMSans-Regular', fontSize: Typography.sm, color: Colors.metalMid, textAlign: 'center', lineHeight: 20 },
  resendLink: { fontFamily: 'DMSans-Bold', color: Colors.textPrimary },

  field: { gap: 6, marginTop: Spacing.sm },
  label: { fontFamily: 'DMSans-Medium', fontSize: 13, color: Colors.textSecondary },
  inputWrap: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    backgroundColor: Colors.surfaceSubtle, borderRadius: Radius.md,
    borderWidth: 1.5, borderColor: Colors.border, paddingHorizontal: Spacing.base, height: 52,
  },
  inputActive: { borderColor: Colors.textPrimary, backgroundColor: Colors.background },
  input: { flex: 1, fontFamily: 'DMSans-Regular', fontSize: Typography.base, color: Colors.textPrimary },
  errorText: { fontFamily: 'DMSans-Regular', fontSize: 12, color: Colors.error },

  cta: {
    height: 52, borderRadius: Radius.md, backgroundColor: Colors.textPrimary,
    alignItems: 'center', justifyContent: 'center', marginTop: Spacing.sm,
    shadowColor: '#000', shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.15, shadowRadius: 10, elevation: 4,
  },
  ctaDisabled: { opacity: 0.5 },
  ctaText: { fontFamily: 'DMSans-Bold', fontSize: Typography.md, color: '#fff' },

  backToLogin: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, marginTop: Spacing.sm },
  backToLoginText: { fontFamily: 'DMSans-Medium', fontSize: Typography.sm, color: Colors.metalMid },
});
