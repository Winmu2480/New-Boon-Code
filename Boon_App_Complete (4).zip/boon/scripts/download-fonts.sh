#!/bin/bash
# ─── Boon App — Font Setup Script ────────────────────────────────────────────
# Run this ONCE from the boon/ project root to download all required fonts.
# Usage: chmod +x scripts/download-fonts.sh && ./scripts/download-fonts.sh

set -e
FONTS_DIR="assets/fonts"
mkdir -p "$FONTS_DIR"

echo "📦 Downloading Boon app fonts..."

# ── Playfair Display Bold ─────────────────────────────────────────────────────
echo "Downloading Playfair Display Bold..."
curl -L "https://github.com/google/fonts/raw/main/ofl/playfairdisplay/PlayfairDisplay%5Bwght%5D.ttf" \
  -o /tmp/PlayfairDisplay-variable.ttf 2>/dev/null || \
curl -L "https://fonts.gstatic.com/s/playfairdisplay/v30/nuFvD-vYSZviVYUb_rj3ij__anPXJzDwcbmjWBN2PKdFvXDXbtXK-F2qC0s.ttf" \
  -o "$FONTS_DIR/PlayfairDisplay-Bold.ttf"

# Fallback: direct static URL
if [ ! -f "$FONTS_DIR/PlayfairDisplay-Bold.ttf" ]; then
  curl -L "https://fonts.gstatic.com/s/playfairdisplay/v30/nuFiD-vYSZviVYUb_rj3ij__anPXBYf9lW4e3oxXPnGn-pHaU5s.ttf" \
    -o "$FONTS_DIR/PlayfairDisplay-Bold.ttf"
fi

# ── DM Sans ───────────────────────────────────────────────────────────────────
echo "Downloading DM Sans..."
curl -L "https://fonts.gstatic.com/s/dmsans/v14/rP2Hp2ywxg089UriCZOIHTWEBlwu8Q.ttf" \
  -o "$FONTS_DIR/DMSans-Regular.ttf"
curl -L "https://fonts.gstatic.com/s/dmsans/v14/rP2Cp2ywxg089UriAWCrOB-sClQX6Cg.ttf" \
  -o "$FONTS_DIR/DMSans-Medium.ttf"
curl -L "https://fonts.gstatic.com/s/dmsans/v14/rP2Cp2ywxg089UriAS2rOB-sClQX6Cg.ttf" \
  -o "$FONTS_DIR/DMSans-Bold.ttf"

# ── Space Mono ────────────────────────────────────────────────────────────────
echo "Downloading Space Mono..."
curl -L "https://fonts.gstatic.com/s/spacemono/v13/i7dPIFZifjKcF5UAWdDRYEF8RXi4EwQ.ttf" \
  -o "$FONTS_DIR/SpaceMono-Regular.ttf"

# ── Verify ────────────────────────────────────────────────────────────────────
echo ""
echo "✅ Fonts downloaded:"
ls -lh "$FONTS_DIR/"

MISSING=0
for f in PlayfairDisplay-Bold DMSans-Regular DMSans-Medium DMSans-Bold SpaceMono-Regular; do
  if [ ! -f "$FONTS_DIR/$f.ttf" ]; then
    echo "❌ MISSING: $f.ttf"
    MISSING=1
  else
    echo "✓ $f.ttf"
  fi
done

if [ $MISSING -eq 0 ]; then
  echo ""
  echo "🎉 All fonts ready! Run: npx expo start"
else
  echo ""
  echo "⚠️  Some fonts failed. Download them manually from fonts.google.com:"
  echo "   - Playfair Display (Bold weight)"
  echo "   - DM Sans (Regular, Medium, Bold weights)"
  echo "   - Space Mono (Regular weight)"
  echo "   Place .ttf files in: $FONTS_DIR/"
fi
