import { getPool } from '../config/database';
import { getFirestore } from '../config/firebase';

export type NotificationType =
  | 'like'
  | 'comment'
  | 'follow'
  | 'deal_alert'
  | 'price_drop';

export interface Notification {
  id: string;
  userId: string;
  type: NotificationType;
  actorId?: string;
  postId?: string;
  message: string;
  isRead: boolean;
  createdAt: string;
}

// ── Create Notification ───────────────────────────────────────────────────────
export const createNotification = async (data: {
  userId: string;
  type: NotificationType;
  actorId?: string;
  postId?: string;
  message: string;
}): Promise<void> => {
  const db = getPool();
  await db.query(
    `INSERT INTO notifications (user_id, type, actor_id, post_id, message)
     VALUES ($1, $2, $3, $4, $5)`,
    [data.userId, data.type, data.actorId || null, data.postId || null, data.message]
  );
};

// ── Get User Notifications ────────────────────────────────────────────────────
export const getUserNotifications = async (
  userId: string,
  limit = 30,
  offset = 0
): Promise<Notification[]> => {
  const db = getPool();
  const result = await db.query(
    `SELECT id, user_id, type, actor_id, post_id, message, is_read, created_at
     FROM notifications
     WHERE user_id = $1
     ORDER BY created_at DESC
     LIMIT $2 OFFSET $3`,
    [userId, limit, offset]
  );

  return result.rows.map((r) => ({
    id: r.id,
    userId: r.user_id,
    type: r.type,
    actorId: r.actor_id,
    postId: r.post_id,
    message: r.message,
    isRead: r.is_read,
    createdAt: r.created_at,
  }));
};

// ── Mark Notifications Read ───────────────────────────────────────────────────
export const markNotificationsRead = async (
  userId: string,
  notificationIds?: string[]
): Promise<void> => {
  const db = getPool();
  if (notificationIds?.length) {
    await db.query(
      `UPDATE notifications SET is_read = TRUE
       WHERE user_id = $1 AND id = ANY($2)`,
      [userId, notificationIds]
    );
  } else {
    // Mark all read
    await db.query(
      `UPDATE notifications SET is_read = TRUE WHERE user_id = $1`,
      [userId]
    );
  }
};

// ── Unread Count ──────────────────────────────────────────────────────────────
export const getUnreadCount = async (userId: string): Promise<number> => {
  const db = getPool();
  const result = await db.query(
    `SELECT COUNT(*) as count FROM notifications
     WHERE user_id = $1 AND is_read = FALSE`,
    [userId]
  );
  return parseInt(result.rows[0].count, 10);
};
