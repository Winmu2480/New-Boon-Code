import { useEffect } from 'react';
import { View, ActivityIndicator } from 'react-native';
import { router } from 'expo-router';
import { useDispatch } from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { subscribeToAuth, getUserDocument } from '../services/authService';
import { setUser, clearAuth } from '../store/authSlice';
import { AppDispatch } from '../store';
import { Colors } from '../constants/theme';

export default function Index() {
  const dispatch = useDispatch<AppDispatch>();

  useEffect(() => {
    const unsubscribe = subscribeToAuth(async (fbUser) => {
      if (fbUser) {
        try {
          const token = await fbUser.getIdToken(false);
          const userDoc = await getUserDocument(fbUser.uid);
          if (userDoc) {
            dispatch(setUser({ user: userDoc, token }));
            router.replace('/(tabs)');
          } else {
            router.replace('/(auth)/register');
          }
        } catch {
          dispatch(clearAuth());
          router.replace('/(auth)/login');
        }
      } else {
        dispatch(clearAuth());
        // Check if first-time user — show onboarding, else go to login
        try {
          const seen = await AsyncStorage.getItem('boon_onboarded');
          router.replace(seen ? '/(auth)/login' : '/onboarding');
        } catch {
          router.replace('/(auth)/login');
        }
      }
    });
    return unsubscribe;
  }, []);

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: Colors.background }}>
      <ActivityIndicator color={Colors.metalMid} size="large" />
    </View>
  );
}
