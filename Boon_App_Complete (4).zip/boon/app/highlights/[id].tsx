import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, Text, StyleSheet, Image, TouchableOpacity,
  Dimensions, StatusBar, Platform,
} from 'react-native';
import { useLocalSearchParams, router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import Animated, {
  useSharedValue, useAnimatedStyle, withTiming,
  runOnJS, withSpring,
} from 'react-native-reanimated';
import { GestureDetector, Gesture } from 'react-native-gesture-handler';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../../services/firebase';

const { width: W, height: H } = Dimensions.get('window');
const STORY_DURATION = 5000; // 5 seconds per story

interface Highlight {
  id: string;
  name: string;
  userId: string;
  images: string[];
  coverImage?: string;
}

export default function HighlightViewer() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const insets = useSafeAreaInsets();
  const [highlight, setHighlight] = useState<Highlight | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [paused, setPaused] = useState(false);

  const progress = useSharedValue(0);
  const translateY = useSharedValue(0);
  const scale = useSharedValue(1);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Fetch highlight data
  useEffect(() => {
    if (!id) return;
    getDoc(doc(db, 'highlights', id)).then((snap) => {
      if (snap.exists()) {
        setHighlight({ id: snap.id, ...snap.data() } as Highlight);
      }
    });
  }, [id]);

  const goNext = useCallback(() => {
    if (!highlight) return;
    if (currentIndex < highlight.images.length - 1) {
      setCurrentIndex((i) => i + 1);
      progress.value = 0;
    } else {
      router.back();
    }
  }, [currentIndex, highlight]);

  const goPrev = useCallback(() => {
    if (currentIndex > 0) {
      setCurrentIndex((i) => i - 1);
      progress.value = 0;
    }
  }, [currentIndex]);

  // Auto-advance timer
  useEffect(() => {
    if (!highlight || paused) return;
    progress.value = 0;
    progress.value = withTiming(1, { duration: STORY_DURATION }, (finished) => {
      if (finished) runOnJS(goNext)();
    });

    return () => {
      progress.value = 0;
    };
  }, [currentIndex, highlight, paused]);

  // Swipe down to close
  const swipeGesture = Gesture.Pan()
    .onUpdate((e) => {
      if (e.translationY > 0) {
        translateY.value = e.translationY;
        scale.value = 1 - (e.translationY / H) * 0.15;
      }
    })
    .onEnd((e) => {
      if (e.translationY > 120) {
        translateY.value = withTiming(H, { duration: 300 });
        scale.value = withTiming(0.85, { duration: 300 }, () => {
          runOnJS(router.back)();
        });
      } else {
        translateY.value = withSpring(0);
        scale.value = withSpring(1);
      }
    });

  const containerStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: translateY.value }, { scale: scale.value }],
  }));

  // Tap left/right halves to navigate
  const handleTap = (side: 'left' | 'right') => {
    if (side === 'left') goPrev();
    else goNext();
  };

  if (!highlight) {
    return <View style={styles.loading} />;
  }

  const currentImage = highlight.images[currentIndex];

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />
      <GestureDetector gesture={swipeGesture}>
        <Animated.View style={[styles.inner, containerStyle]}>
          {/* Background image */}
          <Image source={{ uri: currentImage }} style={styles.image} resizeMode="cover" />

          {/* Dark overlay */}
          <View style={styles.overlay} />

          {/* Progress bars */}
          <View style={[styles.progressRow, { paddingTop: insets.top + 8 }]}>
            {highlight.images.map((_, i) => (
              <ProgressBar
                key={i}
                index={i}
                currentIndex={currentIndex}
                progress={progress}
                total={highlight.images.length}
              />
            ))}
          </View>

          {/* Header */}
          <View style={[styles.header, { top: insets.top + 28 }]}>
            <View style={styles.userInfo}>
              <View style={styles.avatarCircle} />
              <View>
                <Text style={styles.highlightName}>{highlight.name}</Text>
                <Text style={styles.storyCount}>
                  {currentIndex + 1} / {highlight.images.length}
                </Text>
              </View>
            </View>
            <TouchableOpacity onPress={() => router.back()} hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}>
              <Feather name="x" size={24} color="#fff" />
            </TouchableOpacity>
          </View>

          {/* Tap zones */}
          <View style={styles.tapZones}>
            <TouchableOpacity
              style={styles.tapZoneLeft}
              onPress={() => handleTap('left')}
              onLongPress={() => setPaused(true)}
              onPressOut={() => setPaused(false)}
              activeOpacity={1}
            />
            <TouchableOpacity
              style={styles.tapZoneRight}
              onPress={() => handleTap('right')}
              onLongPress={() => setPaused(true)}
              onPressOut={() => setPaused(false)}
              activeOpacity={1}
            />
          </View>

          {/* Pause indicator */}
          {paused && (
            <View style={styles.pauseIndicator}>
              <Feather name="pause" size={32} color="rgba(255,255,255,0.7)" />
            </View>
          )}

          {/* Swipe down hint */}
          <View style={[styles.swipeHint, { bottom: insets.bottom + 20 }]}>
            <Feather name="chevron-down" size={20} color="rgba(255,255,255,0.4)" />
            <Text style={styles.swipeHintText}>Swipe down to close</Text>
          </View>
        </Animated.View>
      </GestureDetector>
    </View>
  );
}

// ── Progress Bar ──────────────────────────────────────────────────────────────
function ProgressBar({ index, currentIndex, progress, total }: {
  index: number;
  currentIndex: number;
  progress: Animated.SharedValue<number>;
  total: number;
}) {
  const fillStyle = useAnimatedStyle(() => {
    let width: number;
    if (index < currentIndex) {
      width = 100;
    } else if (index === currentIndex) {
      width = progress.value * 100;
    } else {
      width = 0;
    }
    return { width: `${width}%` };
  });

  return (
    <View style={[styles.progressTrack, { width: `${(1 / total) * 100}%` }]}>
      <Animated.View style={[styles.progressFill, fillStyle]} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  loading: { flex: 1, backgroundColor: '#000' },
  inner: { flex: 1 },
  image: { position: 'absolute', width: W, height: H },
  overlay: {
    position: 'absolute', width: W, height: H,
    backgroundColor: 'rgba(0,0,0,0.15)',
  },
  progressRow: {
    position: 'absolute', top: 0, left: 0, right: 0,
    flexDirection: 'row', paddingHorizontal: 8, gap: 3, zIndex: 10,
  },
  progressTrack: {
    height: 2.5, backgroundColor: 'rgba(255,255,255,0.35)',
    borderRadius: 2, overflow: 'hidden',
  },
  progressFill: { height: '100%', backgroundColor: '#fff', borderRadius: 2 },
  header: {
    position: 'absolute', left: 0, right: 0,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, zIndex: 10,
  },
  userInfo: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  avatarCircle: {
    width: 32, height: 32, borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.3)',
    borderWidth: 1.5, borderColor: 'rgba(255,255,255,0.6)',
  },
  highlightName: {
    fontFamily: 'DMSans-Bold', fontSize: 14, color: '#fff',
    textShadowColor: 'rgba(0,0,0,0.5)', textShadowRadius: 4,
  },
  storyCount: {
    fontFamily: 'DMSans-Regular', fontSize: 11,
    color: 'rgba(255,255,255,0.7)',
  },
  tapZones: {
    position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
    flexDirection: 'row', zIndex: 5,
  },
  tapZoneLeft: { flex: 1 },
  tapZoneRight: { flex: 1 },
  pauseIndicator: {
    position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
    alignItems: 'center', justifyContent: 'center', zIndex: 8,
  },
  swipeHint: {
    position: 'absolute', left: 0, right: 0,
    alignItems: 'center', gap: 2, zIndex: 10,
  },
  swipeHintText: {
    fontFamily: 'DMSans-Regular', fontSize: 12,
    color: 'rgba(255,255,255,0.35)',
  },
});
