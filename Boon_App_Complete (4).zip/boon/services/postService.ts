import {
  collection, doc, addDoc, getDoc, getDocs, updateDoc, deleteDoc,
  query, where, orderBy, limit, startAfter, serverTimestamp,
  increment, arrayUnion, arrayRemove, DocumentSnapshot,
} from 'firebase/firestore';
import { ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { db, storage } from './firebase';
import { Post, Comment, OGMetadata, User } from '../types';

const POSTS_PER_PAGE = 10;

// ─── FIX #3 helper: fetch + embed author snapshot ─────────────────────────────
const embedAuthor = async (posts: Post[], currentUserId?: string): Promise<Post[]> => {
  // Collect unique author IDs we need
  const authorIds = [...new Set(posts.map((p) => p.authorId))];

  // Batch-fetch all authors in one pass (Firestore limit: 30 per in-query)
  const authors: Record<string, User> = {};
  for (let i = 0; i < authorIds.length; i += 10) {
    const batch = authorIds.slice(i, i + 10);
    const snaps = await getDocs(
      query(collection(db, 'users'), where('__name__', 'in', batch))
    );
    snaps.forEach((s) => { authors[s.id] = { id: s.id, ...s.data() } as User; });
  }

  return posts.map((p) => ({
    ...p,
    author: authors[p.authorId] || null,
    isLiked:  currentUserId ? (p as any).likedBy?.includes(currentUserId) ?? false : false,
    isSaved:  currentUserId ? (p as any).savedBy?.includes(currentUserId) ?? false : false,
  }));
};

// ─── Feed (following) ─────────────────────────────────────────────────────────
export const fetchFeedPosts = async (
  followingIds: string[],
  currentUserId: string,
  lastDoc?: DocumentSnapshot,
  pageSize = POSTS_PER_PAGE
): Promise<{ posts: Post[]; lastDoc: DocumentSnapshot | null }> => {
  if (followingIds.length === 0) return { posts: [], lastDoc: null };

  let q = query(
    collection(db, 'posts'),
    where('authorId', 'in', followingIds.slice(0, 10)),
    orderBy('createdAt', 'desc'),
    limit(pageSize)
  );
  if (lastDoc) q = query(q, startAfter(lastDoc));

  const snap = await getDocs(q);
  const raw = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Post));
  const posts = await embedAuthor(raw, currentUserId);
  return { posts, lastDoc: snap.docs[snap.docs.length - 1] || null };
};

// ─── Discover feed ────────────────────────────────────────────────────────────
export const fetchDiscoverPosts = async (
  currentUserId?: string,
  lastDoc?: DocumentSnapshot,
  pageSize = POSTS_PER_PAGE
): Promise<{ posts: Post[]; lastDoc: DocumentSnapshot | null }> => {
  let q = query(
    collection(db, 'posts'),
    orderBy('createdAt', 'desc'),
    limit(pageSize)
  );
  if (lastDoc) q = query(q, startAfter(lastDoc));

  const snap = await getDocs(q);
  const raw = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Post));
  const posts = await embedAuthor(raw, currentUserId);
  return { posts, lastDoc: snap.docs[snap.docs.length - 1] || null };
};

// ─── FIX #3: Create post — author snapshot written INTO the document ──────────
export const createPost = async (
  author: User,
  imageUri: string,
  data: {
    caption: string;
    storeName: string;
    storeUrl: string;
    storeLocation?: Post['storeLocation'];
    tags?: string[];
  },
  onProgress?: (progress: number) => void
): Promise<Post> => {
  // 1. Upload image
  const imageUrl = await uploadImage(author.id, imageUri, onProgress);

  // 2. Fetch OG metadata (non-blocking)
  let ogMetadata: OGMetadata | undefined;
  try {
    const apiUrl = `${process.env.EXPO_PUBLIC_API_URL || ''}/api/og?url=${encodeURIComponent(data.storeUrl)}`;
    const res = await fetch(apiUrl);
    const json = await res.json();
    if (json.success) ogMetadata = json.data;
  } catch { /* OG is optional */ }

  // 3. Embed a lightweight author snapshot so feed posts need no extra fetches
  const authorSnapshot = {
    id: author.id,
    displayName: author.displayName,
    username: author.username,
    avatar: author.avatar || null,
  };

  const postData = {
    authorId: author.id,
    author: authorSnapshot,           // ← denormalized — eliminates join on read
    imageUrl,
    caption: data.caption,
    storeName: data.storeName,
    storeUrl: data.storeUrl,
    storeLocation: data.storeLocation || null,
    ogMetadata: ogMetadata || null,
    likesCount: 0,
    commentsCount: 0,
    savesCount: 0,
    likedBy: [],
    savedBy: [],
    tags: data.tags || [],
    createdAt: serverTimestamp(),
  };

  const docRef = await addDoc(collection(db, 'posts'), postData);
  await updateDoc(doc(db, 'users', author.id), { postsCount: increment(1) });

  return {
    id: docRef.id,
    ...postData,
    author: { ...authorSnapshot, bio: '', followersCount: 0, followingCount: 0, postsCount: 0, savedDeals: [], email: '', createdAt: '' },
    isLiked: false,
    isSaved: false,
    createdAt: new Date().toISOString(),
  } as Post;
};

// ─── Image upload ─────────────────────────────────────────────────────────────
const uploadImage = (
  userId: string,
  uri: string,
  onProgress?: (p: number) => void
): Promise<string> => {
  return new Promise(async (resolve, reject) => {
    const response = await fetch(uri);
    const blob = await response.blob();
    const filename = `posts/${userId}/${Date.now()}.jpg`;
    const storageRef = ref(storage, filename);
    const task = uploadBytesResumable(storageRef, blob);

    task.on(
      'state_changed',
      (snap) => onProgress?.((snap.bytesTransferred / snap.totalBytes) * 100),
      reject,
      async () => resolve(await getDownloadURL(task.snapshot.ref))
    );
  });
};

// ─── OG Metadata (direct fallback if no backend) ─────────────────────────────
export const fetchOGMetadata = async (url: string): Promise<OGMetadata | null> => {
  try {
    const apiUrl = `${process.env.EXPO_PUBLIC_API_URL || ''}/api/og?url=${encodeURIComponent(url)}`;
    const res = await fetch(apiUrl);
    const json = await res.json();
    return json.success ? json.data : null;
  } catch {
    return null;
  }
};

// ─── Likes ────────────────────────────────────────────────────────────────────
export const toggleLike = async (postId: string, userId: string, isCurrentlyLiked: boolean) => {
  const ref = doc(db, 'posts', postId);
  await updateDoc(ref, {
    likesCount: increment(isCurrentlyLiked ? -1 : 1),
    likedBy: isCurrentlyLiked ? arrayRemove(userId) : arrayUnion(userId),
  });
};

// ─── Save / Wishlist ──────────────────────────────────────────────────────────
export const toggleSave = async (postId: string, userId: string, isCurrentlySaved: boolean) => {
  await Promise.all([
    updateDoc(doc(db, 'posts', postId), {
      savesCount: increment(isCurrentlySaved ? -1 : 1),
      savedBy: isCurrentlySaved ? arrayRemove(userId) : arrayUnion(userId),
    }),
    updateDoc(doc(db, 'users', userId), {
      savedDeals: isCurrentlySaved ? arrayRemove(postId) : arrayUnion(postId),
    }),
  ]);
};

// ─── Comments ─────────────────────────────────────────────────────────────────
export const fetchComments = async (postId: string): Promise<Comment[]> => {
  const snap = await getDocs(
    query(
      collection(db, 'posts', postId, 'comments'),
      orderBy('createdAt', 'asc')
    )
  );
  return snap.docs.map((d) => ({ id: d.id, ...d.data() } as Comment));
};

export const addComment = async (
  postId: string,
  authorId: string,
  text: string
): Promise<Comment> => {
  const data = {
    postId, authorId, text,
    likesCount: 0, likedBy: [],
    createdAt: serverTimestamp(),
  };
  const ref = await addDoc(collection(db, 'posts', postId, 'comments'), data);
  await updateDoc(doc(db, 'posts', postId), { commentsCount: increment(1) });
  return { id: ref.id, ...data, createdAt: new Date().toISOString() } as unknown as Comment;
};

// ─── Delete post ──────────────────────────────────────────────────────────────
export const deletePost = async (postId: string, authorId: string) => {
  await deleteDoc(doc(db, 'posts', postId));
  await updateDoc(doc(db, 'users', authorId), { postsCount: increment(-1) });
};
