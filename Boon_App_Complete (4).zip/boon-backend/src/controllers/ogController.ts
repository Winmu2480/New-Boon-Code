import { Request, Response, NextFunction } from 'express';
import { z } from 'zod';
import { fetchOGMetadata } from '../services/ogService';

const QuerySchema = z.object({
  url: z.string().url('Must be a valid URL'),
});

// GET /api/og?url=https://...
export const getOGMetadata = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { url } = QuerySchema.parse(req.query);
    const metadata = await fetchOGMetadata(url);
    res.json({ success: true, data: metadata });
  } catch (err) {
    next(err);
  }
};
