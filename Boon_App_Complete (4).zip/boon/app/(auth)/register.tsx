import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity,
  KeyboardAvoidingView, Platform, ScrollView,
  ActivityIndicator, StatusBar,
} from 'react-native';
import { router } from 'expo-router';
import { useDispatch, useSelector } from 'react-redux';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import Animated, { FadeInDown, FadeInRight, FadeOutLeft } from 'react-native-reanimated';
import { Colors, Typography, Spacing, Radius, Shadow } from '../../constants/theme';
import { registerWithEmail, clearError } from '../../store/authSlice';
import { AppDispatch, RootState } from '../../store';

// ── 2-step registration: Account Info → Personal Details ─────────────────────
type Step = 1 | 2;

interface FormData {
  email: string;
  password: string;
  confirmPassword: string;
  displayName: string;
  username: string;
}

export default function RegisterScreen() {
  const dispatch = useDispatch<AppDispatch>();
  const insets = useSafeAreaInsets();
  const { isLoading, error } = useSelector((s: RootState) => s.auth);

  const [step, setStep] = useState<Step>(1);
  const [focused, setFocused] = useState<string | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [formError, setFormError] = useState('');

  const [form, setForm] = useState<FormData>({
    email: '', password: '', confirmPassword: '',
    displayName: '', username: '',
  });

  const set = (key: keyof FormData) => (val: string) => {
    setForm((f) => ({ ...f, [key]: val }));
    setFormError('');
    dispatch(clearError());
  };

  const validateStep1 = () => {
    if (!form.email.trim()) { setFormError('Email is required'); return false; }
    if (!/\S+@\S+\.\S+/.test(form.email)) { setFormError('Enter a valid email address'); return false; }
    if (form.password.length < 6) { setFormError('Password must be at least 6 characters'); return false; }
    if (form.password !== form.confirmPassword) { setFormError('Passwords do not match'); return false; }
    return true;
  };

  const validateStep2 = () => {
    if (!form.displayName.trim()) { setFormError('Full name is required'); return false; }
    if (!form.username.trim()) { setFormError('Username is required'); return false; }
    if (form.username.length < 3) { setFormError('Username must be at least 3 characters'); return false; }
    if (!/^[a-z0-9_]+$/.test(form.username)) { setFormError('Username: lowercase letters, numbers, underscores only'); return false; }
    return true;
  };

  const handleNext = () => {
    if (!validateStep1()) return;
    setStep(2);
  };

  const handleCreate = async () => {
    if (!validateStep2()) return;
    const result = await dispatch(registerWithEmail({
      email: form.email.trim(),
      password: form.password,
      displayName: form.displayName.trim(),
      username: form.username.trim().toLowerCase(),
    }));
    if (registerWithEmail.fulfilled.match(result)) router.replace('/(tabs)');
  };

  const anyError = formError || error;

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <StatusBar barStyle="dark-content" />
      <View style={[styles.topBar, { paddingTop: insets.top + 8 }]}>
        <TouchableOpacity
          onPress={step === 1 ? () => router.back() : () => { setStep(1); setFormError(''); }}
          style={styles.backBtn}
        >
          <Feather name="arrow-left" size={20} color={Colors.textPrimary} />
        </TouchableOpacity>

        {/* Step indicator */}
        <View style={styles.stepWrap}>
          {[1, 2].map((n) => (
            <View key={n} style={[styles.stepDot, step >= n && styles.stepDotActive]} />
          ))}
        </View>

        <View style={{ width: 40 }} />
      </View>

      <ScrollView
        contentContainerStyle={[styles.scroll, { paddingBottom: insets.bottom + 40 }]}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {step === 1 ? (
          <Animated.View entering={FadeInRight.duration(380)} key="step1" style={styles.content}>
            <View style={styles.headingWrap}>
              <Text style={styles.stepLabel}>Step 1 of 2</Text>
              <Text style={styles.title}>Create account</Text>
              <Text style={styles.subtitle}>Start your shopping journey on Boon</Text>
            </View>

            {anyError && (
              <View style={styles.errorBanner}>
                <Feather name="alert-circle" size={14} color={Colors.error} />
                <Text style={styles.errorText}>{anyError}</Text>
              </View>
            )}

            <View style={styles.fields}>
              {/* Email */}
              <InputField
                label="Email address"
                icon="mail"
                value={form.email}
                onChange={set('email')}
                placeholder="you@example.com"
                keyboardType="email-address"
                autoCapitalize="none"
                focused={focused === 'email'}
                onFocus={() => setFocused('email')}
                onBlur={() => setFocused(null)}
                returnKeyType="next"
              />

              {/* Password */}
              <InputField
                label="Password"
                icon="lock"
                value={form.password}
                onChange={set('password')}
                placeholder="Min. 6 characters"
                secureTextEntry={!showPassword}
                focused={focused === 'password'}
                onFocus={() => setFocused('password')}
                onBlur={() => setFocused(null)}
                rightIcon={
                  <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
                    <Feather name={showPassword ? 'eye-off' : 'eye'} size={16} color={Colors.metalMid} />
                  </TouchableOpacity>
                }
              />

              {/* Confirm */}
              <InputField
                label="Confirm password"
                icon="lock"
                value={form.confirmPassword}
                onChange={set('confirmPassword')}
                placeholder="Re-enter password"
                secureTextEntry={!showConfirm}
                focused={focused === 'confirm'}
                onFocus={() => setFocused('confirm')}
                onBlur={() => setFocused(null)}
                returnKeyType="done"
                rightIcon={
                  <TouchableOpacity onPress={() => setShowConfirm(!showConfirm)}>
                    <Feather name={showConfirm ? 'eye-off' : 'eye'} size={16} color={Colors.metalMid} />
                  </TouchableOpacity>
                }
              />
            </View>

            {/* Password strength hints */}
            <View style={styles.hints}>
              <PasswordHint met={form.password.length >= 6} text="At least 6 characters" />
              <PasswordHint met={/[A-Z]/.test(form.password)} text="One uppercase letter" />
              <PasswordHint met={/[0-9]/.test(form.password)} text="One number" />
            </View>

            <TouchableOpacity style={styles.cta} onPress={handleNext} activeOpacity={0.85}>
              <Text style={styles.ctaText}>Continue</Text>
              <Feather name="arrow-right" size={18} color="#fff" />
            </TouchableOpacity>

            {/* Divider + Social */}
            <View style={styles.divider}>
              <View style={styles.divLine} />
              <Text style={styles.divLabel}>or sign up with</Text>
              <View style={styles.divLine} />
            </View>
            <View style={styles.socials}>
              {['Google', 'Apple'].map((s) => (
                <TouchableOpacity key={s} style={styles.socialBtn}>
                  <Feather name={s === 'Google' ? 'globe' : 'smartphone'} size={17} color={Colors.textSecondary} />
                  <Text style={styles.socialLabel}>{s}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </Animated.View>
        ) : (
          <Animated.View entering={FadeInRight.duration(380)} key="step2" style={styles.content}>
            <View style={styles.headingWrap}>
              <Text style={styles.stepLabel}>Step 2 of 2</Text>
              <Text style={styles.title}>Your profile</Text>
              <Text style={styles.subtitle}>How should the Boon community know you?</Text>
            </View>

            {anyError && (
              <View style={styles.errorBanner}>
                <Feather name="alert-circle" size={14} color={Colors.error} />
                <Text style={styles.errorText}>{anyError}</Text>
              </View>
            )}

            <View style={styles.fields}>
              <InputField
                label="Full name"
                icon="user"
                value={form.displayName}
                onChange={set('displayName')}
                placeholder="Jane Doe"
                autoCapitalize="words"
                focused={focused === 'name'}
                onFocus={() => setFocused('name')}
                onBlur={() => setFocused(null)}
                returnKeyType="next"
              />
              <InputField
                label="Username"
                icon="at-sign"
                value={form.username}
                onChange={(v) => set('username')(v.toLowerCase().replace(/\s/g, '_'))}
                placeholder="janedoe"
                autoCapitalize="none"
                autoCorrect={false}
                focused={focused === 'username'}
                onFocus={() => setFocused('username')}
                onBlur={() => setFocused(null)}
                returnKeyType="done"
                prefix="@"
              />
            </View>

            <Text style={styles.termsText}>
              By creating an account you agree to our{' '}
              <Text style={styles.termsLink}>Terms of Service</Text> and{' '}
              <Text style={styles.termsLink}>Privacy Policy</Text>.
            </Text>

            <TouchableOpacity
              style={[styles.cta, isLoading && styles.ctaDisabled]}
              onPress={handleCreate}
              disabled={isLoading}
              activeOpacity={0.85}
            >
              {isLoading
                ? <ActivityIndicator color="#fff" />
                : <>
                    <Text style={styles.ctaText}>Create Account</Text>
                    <Feather name="check" size={18} color="#fff" />
                  </>
              }
            </TouchableOpacity>
          </Animated.View>
        )}

        <View style={styles.footer}>
          <Text style={styles.footerText}>Already have an account?</Text>
          <TouchableOpacity onPress={() => router.push('/(auth)/login')}>
            <Text style={styles.footerCta}> Sign in</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

// ── Sub-components ─────────────────────────────────────────────────────────────

interface InputFieldProps {
  label: string; icon: any; value: string; onChange: (v: string) => void;
  placeholder?: string; keyboardType?: any; autoCapitalize?: any;
  secureTextEntry?: boolean; focused: boolean; onFocus: () => void; onBlur: () => void;
  returnKeyType?: any; rightIcon?: React.ReactNode; prefix?: string; autoCorrect?: boolean;
}

function InputField({ label, icon, value, onChange, placeholder, keyboardType, autoCapitalize,
  secureTextEntry, focused, onFocus, onBlur, returnKeyType, rightIcon, prefix, autoCorrect }: InputFieldProps) {
  return (
    <View style={fieldStyles.wrap}>
      <Text style={fieldStyles.label}>{label}</Text>
      <View style={[fieldStyles.row, focused && fieldStyles.rowFocused]}>
        <Feather name={icon} size={16} color={focused ? Colors.textPrimary : Colors.metalLight} />
        {prefix && <Text style={fieldStyles.prefix}>{prefix}</Text>}
        <TextInput
          style={fieldStyles.input}
          placeholder={placeholder}
          placeholderTextColor={Colors.textFaint}
          value={value}
          onChangeText={onChange}
          onFocus={onFocus}
          onBlur={onBlur}
          keyboardType={keyboardType}
          autoCapitalize={autoCapitalize || 'none'}
          secureTextEntry={secureTextEntry}
          returnKeyType={returnKeyType}
          autoCorrect={autoCorrect}
        />
        {rightIcon}
      </View>
    </View>
  );
}

function PasswordHint({ met, text }: { met: boolean; text: string }) {
  return (
    <View style={hintStyles.row}>
      <Feather name={met ? 'check-circle' : 'circle'} size={13} color={met ? Colors.success : Colors.metalSheen} />
      <Text style={[hintStyles.text, met && hintStyles.textMet]}>{text}</Text>
    </View>
  );
}

const fieldStyles = StyleSheet.create({
  wrap: { gap: 6 },
  label: { fontFamily: 'DMSans-Medium', fontSize: 13, color: Colors.textSecondary },
  row: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: Colors.background, borderRadius: Radius.md,
    borderWidth: 1.5, borderColor: Colors.border,
    paddingHorizontal: Spacing.base, height: 52,
  },
  rowFocused: { borderColor: Colors.textPrimary },
  prefix: { fontFamily: 'DMSans-Regular', fontSize: Typography.base, color: Colors.metalMid },
  input: { flex: 1, fontFamily: 'DMSans-Regular', fontSize: Typography.base, color: Colors.textPrimary },
});

const hintStyles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  text: { fontFamily: 'DMSans-Regular', fontSize: 12, color: Colors.metalLight },
  textMet: { color: Colors.success },
});

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  topBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.base, paddingBottom: Spacing.sm,
  },
  backBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: Colors.surface, alignItems: 'center', justifyContent: 'center' },
  stepWrap: { flexDirection: 'row', gap: 6 },
  stepDot: { width: 24, height: 4, borderRadius: 2, backgroundColor: Colors.border },
  stepDotActive: { backgroundColor: Colors.textPrimary },
  scroll: { flexGrow: 1, paddingHorizontal: Spacing.xl },
  content: { gap: Spacing.base, paddingTop: Spacing.md },
  headingWrap: { gap: 4, marginBottom: Spacing.xs },
  stepLabel: { fontFamily: 'DMSans-Regular', fontSize: 12, color: Colors.metalMid, textTransform: 'uppercase', letterSpacing: 1.4 },
  title: { fontFamily: 'Playfair-Bold', fontSize: Typography['2xl'], color: Colors.textPrimary },
  subtitle: { fontFamily: 'DMSans-Regular', fontSize: Typography.sm, color: Colors.metalMid },
  errorBanner: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: Colors.errorLight, borderRadius: Radius.sm,
    padding: Spacing.md, borderWidth: 1, borderColor: Colors.error + '25',
  },
  errorText: { flex: 1, fontFamily: 'DMSans-Regular', fontSize: Typography.sm, color: Colors.error },
  fields: { gap: Spacing.md },
  hints: { gap: 6, backgroundColor: Colors.surfaceSubtle, borderRadius: Radius.md, padding: Spacing.md },
  termsText: { fontFamily: 'DMSans-Regular', fontSize: 12, color: Colors.metalMid, textAlign: 'center', lineHeight: 18 },
  termsLink: { fontFamily: 'DMSans-Bold', color: Colors.textSecondary },
  cta: {
    height: 52, borderRadius: Radius.md, backgroundColor: Colors.textPrimary,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    shadowColor: '#000', shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.15, shadowRadius: 10, elevation: 4,
  },
  ctaDisabled: { opacity: 0.5 },
  ctaText: { fontFamily: 'DMSans-Bold', fontSize: Typography.md, color: '#fff' },
  divider: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  divLine: { flex: 1, height: 1, backgroundColor: Colors.border },
  divLabel: { fontFamily: 'DMSans-Regular', fontSize: 12, color: Colors.metalLight },
  socials: { flexDirection: 'row', gap: Spacing.sm },
  socialBtn: {
    flex: 1, height: 48, borderRadius: Radius.md, borderWidth: 1.5, borderColor: Colors.border,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: Colors.background,
  },
  socialLabel: { fontFamily: 'DMSans-Medium', fontSize: Typography.sm, color: Colors.textSecondary },
  footer: { flexDirection: 'row', justifyContent: 'center', marginTop: Spacing.xl, paddingBottom: Spacing.md },
  footerText: { fontFamily: 'DMSans-Regular', fontSize: Typography.sm, color: Colors.metalMid },
  footerCta: { fontFamily: 'DMSans-Bold', fontSize: Typography.sm, color: Colors.textPrimary },
});
