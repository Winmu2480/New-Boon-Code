import { Request, Response, NextFunction } from 'express';
import { z } from 'zod';
import { findDeals, streamDealChat } from '../services/dealService';
import { trackEvent } from '../services/analyticsService';
import { AuthRequest } from '../middleware/auth';

const FindDealsSchema = z.object({
  storeName: z.string().min(1),
  storeUrl: z.string().url(),
});

const ChatSchema = z.object({
  messages: z.array(
    z.object({
      role: z.enum(['user', 'assistant']),
      content: z.string(),
    })
  ).min(1),
});

// GET /api/deals?storeName=Nike&storeUrl=https://nike.com
export const getDeals = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { storeName, storeUrl } = FindDealsSchema.parse(req.query);
    const deals = await findDeals(storeName, storeUrl);

    // Track analytics
    await trackEvent({
      userId: req.user?.uid,
      eventType: 'deal_finder_query',
      storeUrl,
      metadata: { storeName },
    }).catch(() => {}); // Non-blocking

    res.json({ success: true, data: deals, count: deals.length });
  } catch (err) {
    next(err);
  }
};

// POST /api/deals/chat — Server-Sent Events streaming
export const chatWithDeals = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { messages } = ChatSchema.parse(req.body);

    // Set up SSE headers
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no'); // Disable Nginx buffering
    res.flushHeaders();

    await streamDealChat(messages, (chunk: string) => {
      res.write(`data: ${JSON.stringify({ chunk })}\n\n`);
    });

    res.write('data: [DONE]\n\n');
    res.end();

    // Track analytics
    await trackEvent({
      userId: req.user?.uid,
      eventType: 'deal_finder_query',
    }).catch(() => {});
  } catch (err) {
    next(err);
  }
};
