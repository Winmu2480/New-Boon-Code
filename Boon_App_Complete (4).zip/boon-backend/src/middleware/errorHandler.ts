import { Request, Response, NextFunction } from 'express';
import { ZodError } from 'zod';

// ── Global Error Handler ──────────────────────────────────────────────────────
export const errorHandler = (
  err: any,
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  console.error(`[${new Date().toISOString()}] ERROR ${req.method} ${req.path}:`, err);

  // Zod validation errors
  if (err instanceof ZodError) {
    res.status(400).json({
      error: 'Validation failed',
      details: err.errors.map((e) => ({
        field: e.path.join('.'),
        message: e.message,
      })),
    });
    return;
  }

  // Firebase errors
  if (err.code?.startsWith('auth/')) {
    res.status(401).json({ error: err.message });
    return;
  }

  // Default
  const status = err.status || err.statusCode || 500;
  res.status(status).json({
    error: err.message || 'Internal server error',
  });
};

// ── 404 Handler ───────────────────────────────────────────────────────────────
export const notFound = (req: Request, res: Response): void => {
  res.status(404).json({ error: `Route ${req.method} ${req.path} not found` });
};
