import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity,
  ScrollView, Image, ActivityIndicator, Alert,
  KeyboardAvoidingView, Platform, StatusBar,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { router } from 'expo-router';
import { useDispatch, useSelector } from 'react-redux';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { updateUserProfile } from '../../services/authService';
import { storage } from '../../services/firebase';
import { updateUser } from '../../store/authSlice';
import { Colors, Typography, Spacing, Radius, Shadow } from '../../constants/theme';
import { RootState, AppDispatch } from '../../store';

export default function EditProfileScreen() {
  const dispatch = useDispatch<AppDispatch>();
  const insets = useSafeAreaInsets();
  const { user } = useSelector((s: RootState) => s.auth);

  const [displayName, setDisplayName] = useState(user?.displayName || '');
  const [username, setUsername] = useState(user?.username || '');
  const [bio, setBio] = useState(user?.bio || '');
  const [avatar, setAvatar] = useState<string | null>(user?.avatar || null);
  const [localAvatar, setLocalAvatar] = useState<string | null>(null);

  const [focused, setFocused] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [errors, setErrors] = useState<Partial<Record<string, string>>>({});

  const validate = () => {
    const e: Partial<Record<string, string>> = {};
    if (!displayName.trim()) e.displayName = 'Full name is required';
    if (!username.trim()) e.username = 'Username is required';
    if (username.length < 3) e.username = 'Username must be at least 3 characters';
    if (!/^[a-z0-9_]+$/.test(username)) e.username = 'Lowercase letters, numbers and underscores only';
    if (bio.length > 160) e.bio = `${bio.length}/160 — too long`;
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const pickAvatar = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.85,
    });
    if (!result.canceled) {
      setLocalAvatar(result.assets[0].uri);
    }
  };

  const uploadAvatar = async (): Promise<string | null> => {
    if (!localAvatar || !user) return avatar;
    return new Promise(async (resolve, reject) => {
      const response = await fetch(localAvatar);
      const blob = await response.blob();
      const storageRef = ref(storage, `avatars/${user.id}.jpg`);
      const task = uploadBytesResumable(storageRef, blob);
      task.on('state_changed',
        (snap) => setUploadProgress((snap.bytesTransferred / snap.totalBytes) * 100),
        reject,
        async () => resolve(await getDownloadURL(task.snapshot.ref))
      );
    });
  };

  const handleSave = async () => {
    if (!validate() || !user) return;
    setSaving(true);
    try {
      const avatarUrl = await uploadAvatar();
      const updates = {
        displayName: displayName.trim(),
        username: username.trim().toLowerCase(),
        bio: bio.trim(),
        ...(avatarUrl && { avatar: avatarUrl }),
      };
      await updateUserProfile(user.id, updates);
      dispatch(updateUser({ ...updates, avatar: avatarUrl || user.avatar }));
      router.back();
    } catch (err: any) {
      Alert.alert('Error', err.message || 'Failed to save profile. Please try again.');
    }
    setSaving(false);
  };

  const displayAvatar = localAvatar || avatar;
  const hasChanges =
    displayName !== user?.displayName ||
    username !== user?.username ||
    bio !== (user?.bio || '') ||
    !!localAvatar;

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <StatusBar barStyle="dark-content" />

      {/* ── Nav bar ── */}
      <View style={[styles.nav, { paddingTop: insets.top + 8 }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.navBtn}>
          <Feather name="x" size={20} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.navTitle}>Edit Profile</Text>
        <TouchableOpacity
          onPress={handleSave}
          style={[styles.saveBtn, (!hasChanges || saving) && styles.saveBtnDisabled]}
          disabled={!hasChanges || saving}
        >
          {saving
            ? <ActivityIndicator size="small" color="#fff" />
            : <Text style={styles.saveBtnText}>Save</Text>
          }
        </TouchableOpacity>
      </View>

      {/* Upload progress bar */}
      {saving && uploadProgress > 0 && uploadProgress < 100 && (
        <View style={styles.progressTrack}>
          <View style={[styles.progressFill, { width: `${uploadProgress}%` }]} />
        </View>
      )}

      <ScrollView
        contentContainerStyle={[styles.scroll, { paddingBottom: insets.bottom + 40 }]}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* ── Avatar section ── */}
        <Animated.View entering={FadeInDown.delay(0).duration(400)} style={styles.avatarSection}>
          <View style={styles.avatarWrap}>
            <Image
              source={{ uri: displayAvatar || `https://i.pravatar.cc/200?u=${user?.id}` }}
              style={styles.avatar}
            />
            {/* Metallic overlay ring */}
            <View style={styles.avatarRing} />
          </View>
          <TouchableOpacity style={styles.changePhotoBtn} onPress={pickAvatar} activeOpacity={0.8}>
            <Feather name="camera" size={15} color={Colors.textPrimary} />
            <Text style={styles.changePhotoText}>Change photo</Text>
          </TouchableOpacity>
          {localAvatar && (
            <TouchableOpacity onPress={() => setLocalAvatar(null)}>
              <Text style={styles.removePhotoText}>Remove</Text>
            </TouchableOpacity>
          )}
        </Animated.View>

        {/* ── Divider ── */}
        <View style={styles.sectionDivider}>
          <Text style={styles.sectionLabel}>PROFILE INFO</Text>
        </View>

        {/* ── Fields ── */}
        <Animated.View entering={FadeInDown.delay(80).duration(400)} style={styles.fields}>

          {/* Display name */}
          <View style={styles.fieldGroup}>
            <Text style={styles.fieldLabel}>Full Name</Text>
            <View style={[styles.inputWrap, focused === 'name' && styles.inputFocused, errors.displayName && styles.inputError]}>
              <Feather name="user" size={16} color={focused === 'name' ? Colors.textPrimary : Colors.metalLight} />
              <TextInput
                style={styles.input}
                value={displayName}
                onChangeText={(v) => { setDisplayName(v); setErrors((e) => ({ ...e, displayName: '' })); }}
                onFocus={() => setFocused('name')}
                onBlur={() => setFocused(null)}
                placeholder="Your full name"
                placeholderTextColor={Colors.textFaint}
                autoCapitalize="words"
                returnKeyType="next"
                maxLength={50}
              />
              <Text style={styles.charCount}>{displayName.length}/50</Text>
            </View>
            {errors.displayName ? <Text style={styles.errorMsg}>{errors.displayName}</Text> : null}
          </View>

          {/* Username */}
          <View style={styles.fieldGroup}>
            <Text style={styles.fieldLabel}>Username</Text>
            <View style={[styles.inputWrap, focused === 'username' && styles.inputFocused, errors.username && styles.inputError]}>
              <Text style={styles.atSign}>@</Text>
              <TextInput
                style={styles.input}
                value={username}
                onChangeText={(v) => { setUsername(v.toLowerCase().replace(/\s/g, '_')); setErrors((e) => ({ ...e, username: '' })); }}
                onFocus={() => setFocused('username')}
                onBlur={() => setFocused(null)}
                placeholder="yourusername"
                placeholderTextColor={Colors.textFaint}
                autoCapitalize="none"
                autoCorrect={false}
                returnKeyType="next"
                maxLength={30}
              />
              {username.length >= 3 && !errors.username && (
                <Feather name="check-circle" size={16} color={Colors.success} />
              )}
            </View>
            {errors.username ? <Text style={styles.errorMsg}>{errors.username}</Text> : (
              <Text style={styles.fieldHint}>boon.app/@{username || 'yourusername'}</Text>
            )}
          </View>

          {/* Bio */}
          <View style={styles.fieldGroup}>
            <View style={styles.fieldLabelRow}>
              <Text style={styles.fieldLabel}>Bio</Text>
              <Text style={[styles.charCount, bio.length > 140 && styles.charCountWarn]}>
                {bio.length}/160
              </Text>
            </View>
            <View style={[styles.inputWrap, styles.bioWrap, focused === 'bio' && styles.inputFocused, errors.bio && styles.inputError]}>
              <TextInput
                style={[styles.input, styles.bioInput]}
                value={bio}
                onChangeText={(v) => { setBio(v); setErrors((e) => ({ ...e, bio: '' })); }}
                onFocus={() => setFocused('bio')}
                onBlur={() => setFocused(null)}
                placeholder="Tell the Boon community a little about yourself…"
                placeholderTextColor={Colors.textFaint}
                multiline
                numberOfLines={4}
                maxLength={160}
                textAlignVertical="top"
              />
            </View>
            {errors.bio ? <Text style={styles.errorMsg}>{errors.bio}</Text> : null}
          </View>
        </Animated.View>

        {/* ── Danger zone ── */}
        <Animated.View entering={FadeInDown.delay(160).duration(400)} style={styles.dangerSection}>
          <View style={styles.sectionDivider}>
            <Text style={styles.sectionLabel}>ACCOUNT</Text>
          </View>
          <TouchableOpacity
            style={styles.dangerRow}
            onPress={() => Alert.alert(
              'Sign Out',
              'Are you sure you want to sign out?',
              [
                { text: 'Cancel', style: 'cancel' },
                { text: 'Sign Out', style: 'destructive', onPress: () => router.replace('/(auth)/login') },
              ]
            )}
          >
            <Feather name="log-out" size={18} color={Colors.metalMid} />
            <Text style={styles.dangerRowText}>Sign Out</Text>
            <Feather name="chevron-right" size={16} color={Colors.metalSheen} />
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.dangerRow}
            onPress={() => Alert.alert('Delete Account', 'Please contact support@boonapp.com to delete your account.')}
          >
            <Feather name="trash-2" size={18} color={Colors.error} />
            <Text style={[styles.dangerRowText, { color: Colors.error }]}>Delete Account</Text>
            <Feather name="chevron-right" size={16} color={Colors.metalSheen} />
          </TouchableOpacity>
        </Animated.View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },

  nav: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.base, paddingBottom: Spacing.sm,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  navBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: Colors.surface, alignItems: 'center', justifyContent: 'center' },
  navTitle: { fontFamily: 'DMSans-Bold', fontSize: Typography.md, color: Colors.textPrimary },
  saveBtn: {
    paddingHorizontal: Spacing.base, height: 36, borderRadius: Radius.full,
    backgroundColor: Colors.textPrimary, alignItems: 'center', justifyContent: 'center', minWidth: 64,
  },
  saveBtnDisabled: { backgroundColor: Colors.metalSheen },
  saveBtnText: { fontFamily: 'DMSans-Bold', fontSize: Typography.sm, color: '#fff' },

  progressTrack: { height: 2, backgroundColor: Colors.border },
  progressFill: { height: '100%', backgroundColor: Colors.primary },

  scroll: { paddingHorizontal: Spacing.xl },

  // Avatar
  avatarSection: { alignItems: 'center', paddingVertical: Spacing.xl, gap: Spacing.sm },
  avatarWrap: { position: 'relative' },
  avatar: {
    width: 96, height: 96, borderRadius: 48,
    backgroundColor: Colors.surface,
  },
  avatarRing: {
    position: 'absolute', inset: -3,
    borderRadius: 51, borderWidth: 2,
    borderColor: Colors.metalSheen,
  },
  changePhotoBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: Colors.surfaceSubtle, borderRadius: Radius.full,
    paddingHorizontal: Spacing.base, paddingVertical: 8,
    borderWidth: 1, borderColor: Colors.border,
  },
  changePhotoText: { fontFamily: 'DMSans-Medium', fontSize: Typography.sm, color: Colors.textPrimary },
  removePhotoText: { fontFamily: 'DMSans-Regular', fontSize: Typography.sm, color: Colors.error },

  // Section
  sectionDivider: { paddingVertical: Spacing.sm, marginTop: Spacing.base },
  sectionLabel: { fontFamily: 'DMSans-Bold', fontSize: 10, color: Colors.metalLight, letterSpacing: 1.8 },

  // Fields
  fields: { gap: Spacing.base },
  fieldGroup: { gap: 6 },
  fieldLabel: { fontFamily: 'DMSans-Medium', fontSize: 13, color: Colors.textSecondary },
  fieldLabelRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  fieldHint: { fontFamily: 'DMSans-Regular', fontSize: 12, color: Colors.metalLight },

  inputWrap: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    backgroundColor: Colors.surfaceSubtle, borderRadius: Radius.md,
    borderWidth: 1.5, borderColor: Colors.border,
    paddingHorizontal: Spacing.base, minHeight: 52,
  },
  bioWrap: { alignItems: 'flex-start', paddingVertical: Spacing.sm },
  inputFocused: { borderColor: Colors.textPrimary, backgroundColor: Colors.background },
  inputError: { borderColor: Colors.error },
  atSign: { fontFamily: 'DMSans-Regular', fontSize: Typography.base, color: Colors.metalMid },
  input: { flex: 1, fontFamily: 'DMSans-Regular', fontSize: Typography.base, color: Colors.textPrimary },
  bioInput: { minHeight: 80, paddingTop: 2 },
  charCount: { fontFamily: 'DMSans-Regular', fontSize: 11, color: Colors.metalLight },
  charCountWarn: { color: Colors.warning },
  errorMsg: { fontFamily: 'DMSans-Regular', fontSize: 12, color: Colors.error },

  // Danger zone
  dangerSection: { marginTop: Spacing.lg, marginBottom: Spacing['2xl'] },
  dangerRow: {
    flexDirection: 'row', alignItems: 'center', gap: Spacing.md,
    paddingVertical: Spacing.base,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  dangerRowText: { flex: 1, fontFamily: 'DMSans-Medium', fontSize: Typography.base, color: Colors.textSecondary },
});
