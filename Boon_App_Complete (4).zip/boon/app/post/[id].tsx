import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, Text, StyleSheet, Image, TouchableOpacity, ScrollView,
  TextInput, FlatList, KeyboardAvoidingView, Platform,
  Dimensions, ActivityIndicator, Share, StatusBar,
} from 'react-native';
import { useLocalSearchParams, router } from 'expo-router';
import { useSelector, useDispatch } from 'react-redux';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import Animated, {
  FadeIn, useSharedValue, useAnimatedStyle, withSpring, withSequence,
} from 'react-native-reanimated';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../../services/firebase';
import { fetchComments, addComment, toggleLike, toggleSave } from '../../services/postService';
import { optimisticLike, optimisticSave } from '../../store/feedSlice';
import { addUserMessage, addLoadingMessage } from '../../store/chatSlice';
import { Colors, Typography, Spacing, Radius, Shadow } from '../../constants/theme';
import { Post, Comment } from '../../types';
import { RootState, AppDispatch } from '../../store';

const { width: W } = Dimensions.get('window');

export default function PostDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const dispatch = useDispatch<AppDispatch>();
  const insets = useSafeAreaInsets();
  const { user } = useSelector((s: RootState) => s.auth);
  const feedPosts = useSelector((s: RootState) => s.feed.posts);
  const inputRef = useRef<TextInput>(null);

  const [post, setPost] = useState<Post | null>(
    feedPosts.find((p) => p.id === id) || null
  );
  const [comments, setComments] = useState<Comment[]>([]);
  const [commentText, setCommentText] = useState('');
  const [posting, setPosting] = useState(false);
  const [loadingPost, setLoadingPost] = useState(!post);
  const [loadingComments, setLoadingComments] = useState(true);

  const heartScale = useSharedValue(1);
  const heartAnim = useAnimatedStyle(() => ({ transform: [{ scale: heartScale.value }] }));

  // Load post if not in feed cache
  useEffect(() => {
    if (!post && id) {
      (async () => {
        const snap = await getDoc(doc(db, 'posts', id));
        if (snap.exists()) setPost({ id: snap.id, ...snap.data() } as Post);
        setLoadingPost(false);
      })();
    }
  }, [id]);

  useEffect(() => {
    if (id) {
      fetchComments(id).then((data) => {
        setComments(data);
        setLoadingComments(false);
      });
    }
  }, [id]);

  const handleLike = useCallback(async () => {
    if (!post || !user) return;
    heartScale.value = withSequence(withSpring(1.35, { damping: 4 }), withSpring(1, { damping: 6 }));
    dispatch(optimisticLike({ postId: post.id, userId: user.id }));
    setPost((p) => p ? { ...p, isLiked: !p.isLiked, likesCount: p.likesCount + (p.isLiked ? -1 : 1) } : p);
    await toggleLike(post.id, user.id, post.isLiked);
  }, [post, user]);

  const handleSave = useCallback(async () => {
    if (!post || !user) return;
    dispatch(optimisticSave({ postId: post.id, userId: user.id }));
    setPost((p) => p ? { ...p, isSaved: !p.isSaved, savesCount: p.savesCount + (p.isSaved ? -1 : 1) } : p);
    await toggleSave(post.id, user.id, post.isSaved);
  }, [post, user]);

  const handleComment = async () => {
    if (!commentText.trim() || !post || !user) return;
    setPosting(true);
    const newComment = await addComment(post.id, user.id, commentText.trim());
    setComments((c) => [...c, { ...newComment, author: user }]);
    setPost((p) => p ? { ...p, commentsCount: p.commentsCount + 1 } : p);
    setCommentText('');
    setPosting(false);
  };

  const handleShareToAI = () => {
    if (!post) return;
    dispatch(addUserMessage({ content: `Find me the best deals for this store! 🛍️`, attachedPost: post }));
    dispatch(addLoadingMessage());
    router.push('/(tabs)/deals');
  };

  const handleOpenStore = () => {
    if (!post) return;
    router.push({ pathname: '/browser', params: { url: post.storeUrl, title: post.storeName } });
  };

  const handleShare = async () => {
    if (!post) return;
    await Share.share({
      message: `Check out this find on Boon! ${post.storeName} — ${post.storeUrl}`,
      url: post.storeUrl,
    });
  };

  if (loadingPost || !post) {
    return (
      <View style={[styles.container, styles.centered, { paddingTop: insets.top }]}>
        <ActivityIndicator color={Colors.metalMid} />
      </View>
    );
  }

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <StatusBar barStyle="dark-content" />

      {/* ── Nav ── */}
      <View style={styles.nav}>
        <TouchableOpacity onPress={() => router.back()} style={styles.navBtn}>
          <Feather name="arrow-left" size={20} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.navTitle} numberOfLines={1}>{post.storeName}</Text>
        <TouchableOpacity style={styles.navBtn} onPress={handleShare}>
          <Feather name="share" size={20} color={Colors.textPrimary} />
        </TouchableOpacity>
      </View>

      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={10}>
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>

          {/* ── Post image ── */}
          <Animated.View entering={FadeIn.duration(300)}>
            <Image source={{ uri: post.imageUrl }} style={styles.postImage} resizeMode="cover" />
          </Animated.View>

          {/* ── Author row ── */}
          <TouchableOpacity
            style={styles.authorRow}
            onPress={() => router.push({ pathname: '/profile/[id]', params: { id: post.authorId } })}
            activeOpacity={0.7}
          >
            <Image
              source={{ uri: post.author?.avatar || `https://i.pravatar.cc/80?u=${post.authorId}` }}
              style={styles.authorAvatar}
            />
            <View style={styles.authorInfo}>
              <Text style={styles.authorName}>{post.author?.displayName || 'Boon User'}</Text>
              <Text style={styles.authorUsername}>@{post.author?.username || 'user'}</Text>
            </View>
            <Text style={styles.postTime}>{timeAgo(post.createdAt)}</Text>
          </TouchableOpacity>

          {/* ── Caption ── */}
          {post.caption ? (
            <View style={styles.captionSection}>
              <Text style={styles.caption}>{post.caption}</Text>
              {post.tags?.length > 0 && (
                <View style={styles.tagsRow}>
                  {post.tags.map((t) => <Text key={t} style={styles.tag}>#{t}</Text>)}
                </View>
              )}
            </View>
          ) : null}

          {/* ── Action bar ── */}
          <View style={styles.actions}>
            <View style={styles.actionsLeft}>
              {/* Like */}
              <TouchableOpacity onPress={handleLike} style={styles.actionItem}>
                <Animated.View style={heartAnim}>
                  <Feather name="heart" size={24} color={post.isLiked ? Colors.primary : Colors.textPrimary} />
                </Animated.View>
                {post.likesCount > 0 && <Text style={styles.actionCount}>{fmt(post.likesCount)}</Text>}
              </TouchableOpacity>

              {/* Comment */}
              <TouchableOpacity onPress={() => inputRef.current?.focus()} style={styles.actionItem}>
                <Feather name="message-circle" size={24} color={Colors.textPrimary} />
                {post.commentsCount > 0 && <Text style={styles.actionCount}>{fmt(post.commentsCount)}</Text>}
              </TouchableOpacity>

              {/* Share */}
              <TouchableOpacity onPress={handleShare} style={styles.actionItem}>
                <Feather name="send" size={22} color={Colors.textPrimary} />
              </TouchableOpacity>
            </View>

            <TouchableOpacity onPress={handleSave}>
              <Feather name="bookmark" size={24} color={post.isSaved ? Colors.gold : Colors.textPrimary} />
            </TouchableOpacity>
          </View>

          {/* ── Store card ── */}
          <View style={styles.storeCard}>
            <View style={styles.storeCardLeft}>
              <View style={styles.storeIconWrap}>
                <Feather name="shopping-bag" size={18} color={Colors.metalDark} />
              </View>
              <View>
                <Text style={styles.storeName}>{post.storeName}</Text>
                {post.storeLocation && (
                  <View style={styles.locationRow}>
                    <Feather name="map-pin" size={11} color={Colors.metalLight} />
                    <Text style={styles.locationText}>
                      {post.storeLocation.city}, {post.storeLocation.country}
                    </Text>
                  </View>
                )}
              </View>
            </View>
            <View style={styles.storeActions}>
              <TouchableOpacity style={styles.visitBtn} onPress={handleOpenStore} activeOpacity={0.8}>
                <Text style={styles.visitBtnText}>Visit Store</Text>
                <Feather name="external-link" size={13} color="#fff" />
              </TouchableOpacity>
            </View>
          </View>

          {/* ── OG preview ── */}
          {post.ogMetadata?.image && (
            <TouchableOpacity style={styles.ogCard} onPress={handleOpenStore} activeOpacity={0.85}>
              <Image source={{ uri: post.ogMetadata.image }} style={styles.ogImage} resizeMode="cover" />
              <View style={styles.ogInfo}>
                <Text style={styles.ogSite}>{post.ogMetadata.siteName}</Text>
                <Text style={styles.ogTitle} numberOfLines={2}>{post.ogMetadata.title}</Text>
                {post.ogMetadata.description ? (
                  <Text style={styles.ogDesc} numberOfLines={2}>{post.ogMetadata.description}</Text>
                ) : null}
              </View>
            </TouchableOpacity>
          )}

          {/* ── AI Deal Finder CTA ── */}
          <TouchableOpacity style={styles.aiBanner} onPress={handleShareToAI} activeOpacity={0.85}>
            <View style={styles.aiBannerLeft}>
              <View style={styles.aiIconWrap}>
                <Feather name="zap" size={16} color={Colors.aiPrimary} />
              </View>
              <View>
                <Text style={styles.aiBannerTitle}>Find deals for this store</Text>
                <Text style={styles.aiBannerSub}>Let AI hunt coupons & better prices for you</Text>
              </View>
            </View>
            <Feather name="chevron-right" size={18} color={Colors.metalMid} />
          </TouchableOpacity>

          {/* ── Comments ── */}
          <View style={styles.commentsSection}>
            <Text style={styles.commentsTitle}>
              {comments.length} {comments.length === 1 ? 'Comment' : 'Comments'}
            </Text>

            {loadingComments ? (
              <ActivityIndicator color={Colors.metalLight} style={{ marginTop: Spacing.base }} />
            ) : comments.length === 0 ? (
              <Text style={styles.noComments}>No comments yet — be the first! 💬</Text>
            ) : (
              comments.map((c) => <CommentRow key={c.id} comment={c} />)
            )}
          </View>

          <View style={{ height: 80 }} />
        </ScrollView>

        {/* ── Comment input ── */}
        <View style={[styles.commentInputBar, { paddingBottom: insets.bottom + 8 }]}>
          <Image
            source={{ uri: user?.avatar || `https://i.pravatar.cc/60?u=${user?.id}` }}
            style={styles.commentInputAvatar}
          />
          <TextInput
            ref={inputRef}
            style={styles.commentInput}
            placeholder="Add a comment…"
            placeholderTextColor={Colors.textFaint}
            value={commentText}
            onChangeText={setCommentText}
            multiline
            maxLength={500}
            returnKeyType="send"
          />
          <TouchableOpacity
            style={[styles.commentSendBtn, (!commentText.trim() || posting) && styles.commentSendDisabled]}
            onPress={handleComment}
            disabled={!commentText.trim() || posting}
          >
            {posting
              ? <ActivityIndicator size="small" color="#fff" />
              : <Feather name="send" size={16} color="#fff" />
            }
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}

function CommentRow({ comment }: { comment: Comment }) {
  return (
    <View style={commentStyles.row}>
      <Image
        source={{ uri: comment.author?.avatar || `https://i.pravatar.cc/60?u=${comment.authorId}` }}
        style={commentStyles.avatar}
      />
      <View style={commentStyles.body}>
        <View style={commentStyles.bubble}>
          <Text style={commentStyles.name}>{comment.author?.displayName || 'User'}</Text>
          <Text style={commentStyles.text}>{comment.text}</Text>
        </View>
        <View style={commentStyles.meta}>
          <Text style={commentStyles.time}>{timeAgo(comment.createdAt)}</Text>
          <TouchableOpacity><Text style={commentStyles.reply}>Reply</Text></TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

// ── Helpers ───────────────────────────────────────────────────────────────────
const fmt = (n: number) => n >= 1000 ? (n / 1000).toFixed(1) + 'k' : String(n);
const timeAgo = (iso: string) => {
  const d = Date.now() - new Date(iso).getTime();
  const m = Math.floor(d / 60000);
  if (m < 1) return 'just now';
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h`;
  return `${Math.floor(h / 24)}d`;
};

// ── Styles ────────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  centered: { alignItems: 'center', justifyContent: 'center' },

  nav: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.base, paddingVertical: Spacing.sm,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
  },
  navBtn: { width: 38, height: 38, borderRadius: 19, backgroundColor: Colors.surfaceSubtle, alignItems: 'center', justifyContent: 'center' },
  navTitle: { flex: 1, textAlign: 'center', fontFamily: 'DMSans-Bold', fontSize: Typography.md, color: Colors.textPrimary, marginHorizontal: Spacing.sm },

  scroll: { backgroundColor: Colors.background },
  postImage: { width: W, height: W * 1.05, backgroundColor: Colors.surface },

  authorRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: Spacing.base, paddingVertical: Spacing.md, gap: Spacing.sm },
  authorAvatar: { width: 40, height: 40, borderRadius: 20, backgroundColor: Colors.surface, borderWidth: 1.5, borderColor: Colors.metalSheen },
  authorInfo: { flex: 1 },
  authorName: { fontFamily: 'DMSans-Bold', fontSize: Typography.sm, color: Colors.textPrimary },
  authorUsername: { fontFamily: 'DMSans-Regular', fontSize: 12, color: Colors.metalMid },
  postTime: { fontFamily: 'DMSans-Regular', fontSize: 12, color: Colors.metalLight },

  captionSection: { paddingHorizontal: Spacing.base, paddingBottom: Spacing.md, gap: Spacing.sm },
  caption: { fontFamily: 'DMSans-Regular', fontSize: Typography.base, color: Colors.textSecondary, lineHeight: 22 },
  tagsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  tag: { fontFamily: 'DMSans-Regular', fontSize: 13, color: Colors.primary },

  actions: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.base, paddingVertical: Spacing.sm,
    borderTopWidth: 1, borderBottomWidth: 1, borderColor: Colors.border,
  },
  actionsLeft: { flexDirection: 'row', gap: Spacing.xl },
  actionItem: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  actionCount: { fontFamily: 'DMSans-Medium', fontSize: Typography.sm, color: Colors.textSecondary },

  storeCard: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    marginHorizontal: Spacing.base, marginTop: Spacing.base,
    padding: Spacing.md, borderRadius: Radius.lg,
    backgroundColor: Colors.surfaceSubtle, borderWidth: 1, borderColor: Colors.border,
    ...Shadow.card,
  },
  storeCardLeft: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, flex: 1 },
  storeIconWrap: {
    width: 40, height: 40, borderRadius: 12,
    backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border,
    alignItems: 'center', justifyContent: 'center',
  },
  storeName: { fontFamily: 'DMSans-Bold', fontSize: Typography.sm, color: Colors.textPrimary },
  locationRow: { flexDirection: 'row', alignItems: 'center', gap: 3, marginTop: 2 },
  locationText: { fontFamily: 'DMSans-Regular', fontSize: 11, color: Colors.metalLight },
  storeActions: {},
  visitBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    backgroundColor: Colors.textPrimary, borderRadius: Radius.full,
    paddingHorizontal: Spacing.md, paddingVertical: 8,
  },
  visitBtnText: { fontFamily: 'DMSans-Bold', fontSize: 12, color: '#fff' },

  ogCard: {
    flexDirection: 'row', marginHorizontal: Spacing.base, marginTop: Spacing.sm,
    borderRadius: Radius.md, overflow: 'hidden',
    borderWidth: 1, borderColor: Colors.border, backgroundColor: Colors.surfaceSubtle,
  },
  ogImage: { width: 88, height: 88, backgroundColor: Colors.surface },
  ogInfo: { flex: 1, padding: Spacing.sm, justifyContent: 'center', gap: 3 },
  ogSite: { fontFamily: 'DMSans-Regular', fontSize: 11, color: Colors.metalMid, textTransform: 'uppercase', letterSpacing: 0.5 },
  ogTitle: { fontFamily: 'DMSans-Bold', fontSize: 13, color: Colors.textPrimary, lineHeight: 18 },
  ogDesc: { fontFamily: 'DMSans-Regular', fontSize: 12, color: Colors.metalMid, lineHeight: 16 },

  aiBanner: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    marginHorizontal: Spacing.base, marginTop: Spacing.sm,
    padding: Spacing.md, borderRadius: Radius.lg,
    backgroundColor: Colors.aiSurface, borderWidth: 1, borderColor: Colors.aiPrimary + '20',
  },
  aiBannerLeft: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, flex: 1 },
  aiIconWrap: {
    width: 36, height: 36, borderRadius: 10,
    backgroundColor: Colors.aiBubble, alignItems: 'center', justifyContent: 'center',
  },
  aiBannerTitle: { fontFamily: 'DMSans-Bold', fontSize: Typography.sm, color: Colors.textPrimary },
  aiBannerSub: { fontFamily: 'DMSans-Regular', fontSize: 12, color: Colors.metalMid },

  commentsSection: { paddingHorizontal: Spacing.base, paddingTop: Spacing.xl },
  commentsTitle: { fontFamily: 'DMSans-Bold', fontSize: Typography.md, color: Colors.textPrimary, marginBottom: Spacing.base },
  noComments: { fontFamily: 'DMSans-Regular', fontSize: Typography.sm, color: Colors.metalLight, textAlign: 'center', paddingVertical: Spacing.xl },

  commentInputBar: {
    flexDirection: 'row', alignItems: 'flex-end', gap: Spacing.sm,
    paddingHorizontal: Spacing.base, paddingTop: Spacing.sm,
    borderTopWidth: 1, borderTopColor: Colors.border,
    backgroundColor: Colors.background,
  },
  commentInputAvatar: { width: 32, height: 32, borderRadius: 16, backgroundColor: Colors.surface },
  commentInput: {
    flex: 1, backgroundColor: Colors.surfaceSubtle,
    borderRadius: 22, paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.sm, fontFamily: 'DMSans-Regular',
    fontSize: Typography.sm, color: Colors.textPrimary,
    maxHeight: 90, borderWidth: 1.5, borderColor: Colors.border,
  },
  commentSendBtn: {
    width: 38, height: 38, borderRadius: 19,
    backgroundColor: Colors.textPrimary, alignItems: 'center', justifyContent: 'center',
  },
  commentSendDisabled: { backgroundColor: Colors.metalSheen },
});

const commentStyles = StyleSheet.create({
  row: { flexDirection: 'row', gap: Spacing.sm, marginBottom: Spacing.base },
  avatar: { width: 34, height: 34, borderRadius: 17, backgroundColor: Colors.surface },
  body: { flex: 1 },
  bubble: {
    backgroundColor: Colors.surfaceSubtle, borderRadius: Radius.md, borderTopLeftRadius: 4,
    paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm,
    borderWidth: 1, borderColor: Colors.border,
  },
  name: { fontFamily: 'DMSans-Bold', fontSize: 13, color: Colors.textPrimary, marginBottom: 2 },
  text: { fontFamily: 'DMSans-Regular', fontSize: Typography.sm, color: Colors.textSecondary, lineHeight: 19 },
  meta: { flexDirection: 'row', gap: Spacing.base, marginTop: 4, paddingLeft: Spacing.xs },
  time: { fontFamily: 'DMSans-Regular', fontSize: 11, color: Colors.metalLight },
  reply: { fontFamily: 'DMSans-Medium', fontSize: 11, color: Colors.metalMid },
});
