import { Pool } from 'pg';

let pool: Pool;

export const getPool = (): Pool => {
  if (!pool) {
    pool = new Pool({
      connectionString: process.env.DATABASE_URL,
      ssl: process.env.NODE_ENV === 'production'
        ? { rejectUnauthorized: false }
        : false,
      max: 20,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 2000,
    });

    pool.on('error', (err) => {
      console.error('Unexpected PostgreSQL error:', err);
    });

    console.log('✅ PostgreSQL pool initialized');
  }
  return pool;
};

// ── Run migrations on startup ─────────────────────────────────────────────────
export const runMigrations = async (): Promise<void> => {
  const db = getPool();

  await db.query(`
    CREATE TABLE IF NOT EXISTS deal_cache (
      id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      store_url   TEXT NOT NULL,
      store_name  TEXT NOT NULL,
      deals       JSONB NOT NULL DEFAULT '[]',
      fetched_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      expires_at  TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '6 hours')
    );
    CREATE INDEX IF NOT EXISTS idx_deal_cache_store_url ON deal_cache(store_url);
    CREATE INDEX IF NOT EXISTS idx_deal_cache_expires ON deal_cache(expires_at);
  `);

  await db.query(`
    CREATE TABLE IF NOT EXISTS og_cache (
      id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      url         TEXT UNIQUE NOT NULL,
      title       TEXT,
      description TEXT,
      image       TEXT,
      site_name   TEXT,
      fetched_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      expires_at  TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '24 hours')
    );
    CREATE INDEX IF NOT EXISTS idx_og_cache_url ON og_cache(url);
  `);

  await db.query(`
    CREATE TABLE IF NOT EXISTS notifications (
      id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      user_id     TEXT NOT NULL,
      type        TEXT NOT NULL,
      actor_id    TEXT,
      post_id     TEXT,
      message     TEXT NOT NULL,
      is_read     BOOLEAN DEFAULT FALSE,
      created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, is_read);
  `);

  await db.query(`
    CREATE TABLE IF NOT EXISTS analytics_events (
      id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      user_id     TEXT,
      event_type  TEXT NOT NULL,
      post_id     TEXT,
      store_url   TEXT,
      metadata    JSONB DEFAULT '{}',
      created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE INDEX IF NOT EXISTS idx_analytics_type ON analytics_events(event_type, created_at);
    CREATE INDEX IF NOT EXISTS idx_analytics_user ON analytics_events(user_id, created_at);
  `);

  console.log('✅ Database migrations complete');
};
