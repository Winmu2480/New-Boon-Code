import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from './firebase';
import { router } from 'expo-router';

// ── Configure how notifications appear while app is open ──────────────────────
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

// ── Register device for push notifications ────────────────────────────────────
export const registerForPushNotifications = async (userId: string): Promise<string | null> => {
  // Push notifications only work on real devices
  if (!Device.isDevice) {
    console.log('Push notifications require a real device');
    return null;
  }

  // Request permission
  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;

  if (existingStatus !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }

  if (finalStatus !== 'granted') {
    console.log('Push notification permission denied');
    return null;
  }

  // Android: create a notification channel
  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('boon-default', {
      name: 'Boon Notifications',
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: '#E8334A',
      showBadge: true,
    });

    await Notifications.setNotificationChannelAsync('boon-deals', {
      name: 'Deal Alerts',
      importance: Notifications.AndroidImportance.HIGH,
      vibrationPattern: [0, 500],
      lightColor: '#C8922A',
      showBadge: true,
    });
  }

  // Get the Expo push token
  try {
    const tokenData = await Notifications.getExpoPushTokenAsync({
      projectId: process.env.EXPO_PUBLIC_EXPO_PROJECT_ID,
    });
    const pushToken = tokenData.data;

    // Save token to user's Firestore document
    await updateDoc(doc(db, 'users', userId), {
      pushToken,
      pushTokenUpdatedAt: new Date().toISOString(),
      platform: Platform.OS,
    });

    console.log('Push token registered:', pushToken);
    return pushToken;
  } catch (err) {
    console.error('Failed to get push token:', err);
    return null;
  }
};

// ── Remove push token on logout ───────────────────────────────────────────────
export const unregisterPushNotifications = async (userId: string): Promise<void> => {
  try {
    await updateDoc(doc(db, 'users', userId), {
      pushToken: null,
      pushTokenUpdatedAt: new Date().toISOString(),
    });
    await Notifications.setBadgeCountAsync(0);
  } catch (err) {
    console.error('Failed to unregister push token:', err);
  }
};

// ── Set badge count (iOS) ─────────────────────────────────────────────────────
export const setBadgeCount = async (count: number): Promise<void> => {
  await Notifications.setBadgeCountAsync(count);
};

export const clearBadge = async (): Promise<void> => {
  await Notifications.setBadgeCountAsync(0);
};

// ── Handle notification tap — deep link to relevant screen ───────────────────
export const handleNotificationResponse = (
  response: Notifications.NotificationResponse
): void => {
  const data = response.notification.request.content.data as {
    type?: string;
    postId?: string;
    actorId?: string;
    screen?: string;
  };

  if (!data) return;

  // Route to the relevant screen based on notification type
  switch (data.type) {
    case 'like':
    case 'comment':
      if (data.postId) {
        router.push({ pathname: '/post/[id]', params: { id: data.postId } });
      }
      break;
    case 'follow':
      if (data.actorId) {
        router.push({ pathname: '/profile/[id]', params: { id: data.actorId } });
      }
      break;
    case 'deal_alert':
    case 'price_drop':
      router.push('/(tabs)/deals');
      break;
    default:
      router.push('/(tabs)/notifications');
  }
};

// ── Set up global listeners (call once in app/_layout.tsx) ────────────────────
export const setupNotificationListeners = (): (() => void) => {
  // Fires when a notification arrives while app is open
  const receivedSub = Notifications.addNotificationReceivedListener((notification) => {
    console.log('Notification received:', notification.request.content.title);
    // Optionally update unread badge count in Redux here
  });

  // Fires when user taps a notification
  const responseSub = Notifications.addNotificationResponseReceivedListener(
    handleNotificationResponse
  );

  // Return cleanup function
  return () => {
    receivedSub.remove();
    responseSub.remove();
  };
};

// ── Schedule a local notification (for testing) ───────────────────────────────
export const scheduleLocalNotification = async (
  title: string,
  body: string,
  data?: object,
  delaySeconds = 0
): Promise<void> => {
  await Notifications.scheduleNotificationAsync({
    content: { title, body, data: data || {}, sound: true },
    trigger: delaySeconds > 0 ? { seconds: delaySeconds } : null,
  });
};
