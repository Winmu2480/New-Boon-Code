import { getPool } from '../config/database';

export type EventType =
  | 'store_url_click'    // CTR KPI
  | 'post_view'
  | 'deal_finder_query'  // AI engagement KPI
  | 'post_create'
  | 'follow'
  | 'app_open';          // DAU KPI

// ── Track Event ───────────────────────────────────────────────────────────────
export const trackEvent = async (data: {
  userId?: string;
  eventType: EventType;
  postId?: string;
  storeUrl?: string;
  metadata?: Record<string, any>;
}): Promise<void> => {
  const db = getPool();
  await db.query(
    `INSERT INTO analytics_events (user_id, event_type, post_id, store_url, metadata)
     VALUES ($1, $2, $3, $4, $5)`,
    [
      data.userId || null,
      data.eventType,
      data.postId || null,
      data.storeUrl || null,
      JSON.stringify(data.metadata || {}),
    ]
  );
};

// ── Daily Active Users ────────────────────────────────────────────────────────
export const getDailyActiveUsers = async (days = 30): Promise<{
  date: string;
  count: number;
}[]> => {
  const db = getPool();
  const result = await db.query(
    `SELECT
       DATE(created_at) as date,
       COUNT(DISTINCT user_id) as count
     FROM analytics_events
     WHERE event_type = 'app_open'
       AND created_at >= NOW() - INTERVAL '${days} days'
       AND user_id IS NOT NULL
     GROUP BY DATE(created_at)
     ORDER BY date DESC`
  );
  return result.rows.map((r) => ({ date: r.date, count: parseInt(r.count) }));
};

// ── CTR — Store URL Clicks ────────────────────────────────────────────────────
export const getStoreClickThroughRate = async (days = 30): Promise<{
  clicks: number;
  views: number;
  ctr: number;
}> => {
  const db = getPool();
  const result = await db.query(
    `SELECT
       COUNT(*) FILTER (WHERE event_type = 'store_url_click') as clicks,
       COUNT(*) FILTER (WHERE event_type = 'post_view') as views
     FROM analytics_events
     WHERE created_at >= NOW() - INTERVAL '${days} days'`
  );
  const { clicks, views } = result.rows[0];
  const c = parseInt(clicks) || 0;
  const v = parseInt(views) || 1;
  return { clicks: c, views: v, ctr: parseFloat(((c / v) * 100).toFixed(2)) };
};

// ── Deal Finder Usage ─────────────────────────────────────────────────────────
export const getDealFinderStats = async (days = 7): Promise<{
  totalQueries: number;
  uniqueUsers: number;
  avgQueriesPerUser: number;
}> => {
  const db = getPool();
  const result = await db.query(
    `SELECT
       COUNT(*) as total_queries,
       COUNT(DISTINCT user_id) as unique_users
     FROM analytics_events
     WHERE event_type = 'deal_finder_query'
       AND created_at >= NOW() - INTERVAL '${days} days'`
  );
  const { total_queries, unique_users } = result.rows[0];
  const total = parseInt(total_queries) || 0;
  const users = parseInt(unique_users) || 1;
  return {
    totalQueries: total,
    uniqueUsers: users,
    avgQueriesPerUser: parseFloat((total / users).toFixed(1)),
  };
};

// ── Top Stores by Clicks ──────────────────────────────────────────────────────
export const getTopStores = async (limit = 10): Promise<{
  storeUrl: string;
  clicks: number;
}[]> => {
  const db = getPool();
  const result = await db.query(
    `SELECT store_url, COUNT(*) as clicks
     FROM analytics_events
     WHERE event_type = 'store_url_click'
       AND store_url IS NOT NULL
       AND created_at >= NOW() - INTERVAL '30 days'
     GROUP BY store_url
     ORDER BY clicks DESC
     LIMIT $1`,
    [limit]
  );
  return result.rows.map((r) => ({
    storeUrl: r.store_url,
    clicks: parseInt(r.clicks),
  }));
};
