import React, { useCallback, useEffect, useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
  RefreshControl, ActivityIndicator, StatusBar,
} from 'react-native';
import { FlashList } from '@shopify/flash-list';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { useDispatch, useSelector } from 'react-redux';
import { Feather } from '@expo/vector-icons';
import { Colors, Typography, Spacing, Radius } from '../../constants/theme';
import { AppDispatch, RootState } from '../../store';
import { loadFeed, refreshFeed, loadMoreFeed } from '../../store/feedSlice';
import { addUserMessage, addLoadingMessage } from '../../store/chatSlice';
import PostCard from '../../components/feed/PostCard';
import CommentsSheet from '../../components/feed/CommentsSheet';
import { Post } from '../../types';

export default function FeedScreen() {
  const dispatch = useDispatch<AppDispatch>();
  const insets = useSafeAreaInsets();
  const { user } = useSelector((s: RootState) => s.auth);
  const { posts, isLoading, isRefreshing, isLoadingMore, hasMore } = useSelector(
    (s: RootState) => s.feed as any
  );

  const [commentPost, setCommentPost] = useState<Post | null>(null);

  // Load feed on mount
  useEffect(() => {
    dispatch(loadFeed(user?.id));
  }, []);

  // Pull-to-refresh
  const onRefresh = useCallback(() => {
    dispatch(refreshFeed(user?.id));
  }, [user?.id]);

  // FIX #4: Infinite scroll — triggered when user reaches end of list
  const onEndReached = useCallback(() => {
    if (hasMore && !isLoadingMore && !isLoading) {
      dispatch(loadMoreFeed(user?.id));
    }
  }, [hasMore, isLoadingMore, isLoading, user?.id]);

  const handleShareToAI = useCallback((post: Post) => {
    dispatch(addUserMessage({
      content: `Find me the best deals for this store! 🛍️`,
      attachedPost: post,
    }));
    dispatch(addLoadingMessage());
    router.push('/(tabs)/deals');
  }, []);

  const renderPost = useCallback(
    ({ item }: { item: Post }) => (
      <PostCard
        post={item}
        onCommentPress={setCommentPost}
        onShareToAI={handleShareToAI}
      />
    ),
    []
  );

  const renderFooter = () => {
    if (!isLoadingMore) return <View style={{ height: Spacing.xl }} />;
    return (
      <View style={styles.footerLoader}>
        <ActivityIndicator color={Colors.metalLight} size="small" />
      </View>
    );
  };

  const Separator = () => <View style={styles.separator} />;

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <StatusBar barStyle="dark-content" />

      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.logo}>boon</Text>
        <View style={styles.headerRight}>
          <TouchableOpacity
            onPress={() => router.push('/(tabs)/search')}
            style={styles.headerBtn}
          >
            <Feather name="search" size={20} color={Colors.textPrimary} />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => router.push('/notifications')}
            style={styles.headerBtn}
          >
            <Feather name="bell" size={20} color={Colors.textPrimary} />
          </TouchableOpacity>
        </View>
      </View>

      {/* Feed */}
      {isLoading && posts.length === 0 ? (
        <View style={styles.centered}>
          <ActivityIndicator color={Colors.metalMid} size="large" />
        </View>
      ) : posts.length === 0 ? (
        <EmptyFeed />
      ) : (
        <FlashList
          data={posts}
          renderItem={renderPost}
          keyExtractor={(item: Post) => item.id}
          estimatedItemSize={600}
          ItemSeparatorComponent={Separator}
          ListFooterComponent={renderFooter}
          refreshControl={
            <RefreshControl
              refreshing={isRefreshing}
              onRefresh={onRefresh}
              tintColor={Colors.metalMid}
              colors={[Colors.primary]}
            />
          }
          onEndReached={onEndReached}          // FIX #4: wired here
          onEndReachedThreshold={0.4}          // trigger when 40% from bottom
          showsVerticalScrollIndicator={false}
        />
      )}

      {/* Comments bottom sheet */}
      {commentPost && (
        <CommentsSheet
          post={commentPost}
          onClose={() => setCommentPost(null)}
        />
      )}
    </View>
  );
}

function EmptyFeed() {
  return (
    <View style={styles.emptyWrap}>
      <Text style={styles.emptyEmoji}>🛍️</Text>
      <Text style={styles.emptyTitle}>Your feed is empty</Text>
      <Text style={styles.emptySubtitle}>
        Follow friends or explore to discover amazing store finds
      </Text>
      <TouchableOpacity
        style={styles.exploreBtn}
        onPress={() => router.push('/(tabs)/search')}
      >
        <Text style={styles.exploreBtnText}>Explore Posts</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: Spacing.base, paddingVertical: Spacing.sm,
    borderBottomWidth: 1, borderBottomColor: Colors.border,
    backgroundColor: Colors.background,
  },
  logo: {
    fontFamily: 'Playfair-Bold', fontSize: 26,
    color: Colors.textPrimary, letterSpacing: -0.5,
  },
  headerRight: { flexDirection: 'row', gap: Spacing.sm },
  headerBtn: {
    width: 38, height: 38, borderRadius: 19,
    backgroundColor: Colors.surfaceSubtle,
    alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: Colors.border,
  },
  separator: { height: 1, backgroundColor: Colors.border, marginVertical: 4 },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  footerLoader: {
    paddingVertical: Spacing.xl,
    alignItems: 'center',
  },
  emptyWrap: {
    flex: 1, alignItems: 'center', justifyContent: 'center', padding: Spacing['2xl'],
  },
  emptyEmoji: { fontSize: 56, marginBottom: Spacing.base },
  emptyTitle: {
    fontFamily: 'Playfair-Bold', fontSize: Typography.xl,
    color: Colors.textPrimary, marginBottom: Spacing.sm, textAlign: 'center',
  },
  emptySubtitle: {
    fontFamily: 'DMSans-Regular', fontSize: Typography.base,
    color: Colors.metalMid, textAlign: 'center', lineHeight: 22, marginBottom: Spacing.xl,
  },
  exploreBtn: {
    backgroundColor: Colors.textPrimary,
    paddingHorizontal: Spacing.xl, paddingVertical: Spacing.md,
    borderRadius: Radius.full,
  },
  exploreBtnText: {
    fontFamily: 'DMSans-Bold', fontSize: Typography.base, color: '#fff',
  },
});
