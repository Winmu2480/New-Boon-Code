// ─── Authenticated API Client ─────────────────────────────────────────────────
// FIX #5: Every request calls getFreshToken() which triggers Firebase to
// refresh if the current token has less than 5 minutes remaining.
// This means users are never silently logged out mid-session.

import { getFreshToken } from './authService';

const BASE_URL = process.env.EXPO_PUBLIC_API_URL || '';

interface RequestOptions {
  method?: 'GET' | 'POST' | 'PATCH' | 'DELETE';
  body?: object;
  params?: Record<string, string>;
  authenticated?: boolean;
}

export async function apiRequest<T>(
  path: string,
  options: RequestOptions = {}
): Promise<T> {
  const { method = 'GET', body, params, authenticated = true } = options;

  // Build URL with query params
  const url = new URL(`${BASE_URL}${path}`);
  if (params) {
    Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));
  }

  // Build headers
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };

  // FIX #5: Always fetch a fresh token before every API call
  if (authenticated) {
    const token = await getFreshToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
  }

  const response = await fetch(url.toString(), {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ error: 'Request failed' }));
    throw new Error(errorData.error || `HTTP ${response.status}`);
  }

  return response.json();
}

// ─── Convenience helpers ──────────────────────────────────────────────────────

export const api = {
  get: <T>(path: string, params?: Record<string, string>) =>
    apiRequest<T>(path, { method: 'GET', params }),

  post: <T>(path: string, body?: object) =>
    apiRequest<T>(path, { method: 'POST', body }),

  patch: <T>(path: string, body?: object) =>
    apiRequest<T>(path, { method: 'PATCH', body }),

  delete: <T>(path: string) =>
    apiRequest<T>(path, { method: 'DELETE' }),

  // For public endpoints (OG metadata, discover feed) that don't need auth
  public: <T>(path: string, params?: Record<string, string>) =>
    apiRequest<T>(path, { method: 'GET', params, authenticated: false }),
};
