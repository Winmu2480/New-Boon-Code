// ─── Boon Design System — Light Theme ────────────────────────────────────────
// White background · Black type · Metallic gray accents · Coral CTA

export const Colors = {
  // ── Backgrounds ──────────────────────────────────────────────────────────
  background:       '#FFFFFF',
  surfaceSubtle:    '#F7F7F8',
  surface:          '#F2F2F4',
  surfaceElevated:  '#FFFFFF',
  surfaceMid:       '#EBEBED',

  // ── Borders ───────────────────────────────────────────────────────────────
  border:           '#E0E0E3',
  borderStrong:     '#C8C8CC',

  // ── Text ─────────────────────────────────────────────────────────────────
  textPrimary:      '#0A0A0B',
  textSecondary:    '#3C3C44',
  textMuted:        '#8A8A96',
  textFaint:        '#B8B8C2',

  // ── Metallic ──────────────────────────────────────────────────────────────
  metalDark:        '#4A4A52',
  metalMid:         '#6E6E7A',
  metalLight:       '#A8A8B4',
  metalSheen:       '#D4D4DC',

  // ── Brand ────────────────────────────────────────────────────────────────
  primary:          '#E8334A',
  primaryLight:     '#FDEEF1',
  primaryDark:      '#C5203A',
  gold:             '#C8922A',

  // ── Semantic ─────────────────────────────────────────────────────────────
  success:          '#1A8A5A',
  successLight:     '#E6F5EE',
  error:            '#D4283C',
  errorLight:       '#FDEAEC',
  warning:          '#B87720',
  warningLight:     '#FDF5E6',

  // ── AI Deal Finder ────────────────────────────────────────────────────────
  aiPrimary:        '#3D3D8F',
  aiSurface:        '#F0F0F8',
  aiBubble:         '#EEEEF8',
  aiUserBubble:     '#0A0A0B',

  // ── Overlays ─────────────────────────────────────────────────────────────
  overlay:          'rgba(10,10,11,0.55)',
  overlayLight:     'rgba(10,10,11,0.25)',
} as const;

export const Typography = {
  displayFont:  'Playfair-Bold',
  bodyFont:     'DMSans-Regular',
  bodyMedium:   'DMSans-Medium',
  bodyBold:     'DMSans-Bold',
  monoFont:     'SpaceMono-Regular',
  xs:   11,
  sm:   13,
  base: 15,
  md:   17,
  lg:   20,
  xl:   24,
  '2xl': 30,
  '3xl': 36,
  '4xl': 48,
} as const;

export const Spacing = {
  xs:    4,
  sm:    8,
  md:    12,
  base:  16,
  lg:    20,
  xl:    24,
  '2xl': 32,
  '3xl': 48,
  '4xl': 64,
} as const;

export const Radius = {
  xs:   4,
  sm:   8,
  md:   12,
  lg:   18,
  xl:   24,
  full: 9999,
} as const;

export const Shadow = {
  card: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.07,
    shadowRadius: 8,
    elevation: 3,
  },
  strong: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 16,
    elevation: 6,
  },
  button: {
    shadowColor: '#E8334A',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.28,
    shadowRadius: 10,
    elevation: 5,
  },
} as const;
