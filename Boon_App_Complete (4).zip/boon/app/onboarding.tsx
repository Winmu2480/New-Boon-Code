import React, { useRef, useState } from 'react';
import {
  View, Text, StyleSheet, Dimensions, TouchableOpacity,
  FlatList, StatusBar, Platform,
} from 'react-native';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Animated, {
  useSharedValue, useAnimatedStyle, withSpring,
  interpolate, Extrapolation,
} from 'react-native-reanimated';
import { Colors, Typography, Spacing, Radius } from '../constants/theme';

const { width: W, height: H } = Dimensions.get('window');

const SLIDES = [
  {
    id: '1',
    emoji: '🛍️',
    title: 'Discover what\nyour friends love',
    subtitle: 'Follow friends and scroll a beautiful feed of their real store finds — no ads, no influencers.',
    bg: '#0A0A0B',
    accent: Colors.primary,
  },
  {
    id: '2',
    emoji: '🔗',
    title: 'Every post is\nshoppable',
    subtitle: 'Every find links directly to the store. One tap opens it in a safe in-app browser. No more hunting.',
    bg: '#111827',
    accent: '#6366F1',
  },
  {
    id: '3',
    emoji: '⚡',
    title: 'AI hunts deals\nfor you',
    subtitle: 'Share any post with our AI Deal Finder and it instantly finds coupons, discounts and better prices.',
    bg: '#0A0A0B',
    accent: Colors.gold,
  },
];

export default function OnboardingScreen() {
  const insets = useSafeAreaInsets();
  const flatRef = useRef<FlatList>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const scrollX = useSharedValue(0);

  const finish = async () => {
    await AsyncStorage.setItem('boon_onboarded', 'true');
    router.replace('/(auth)/login');
  };

  const next = () => {
    if (currentIndex < SLIDES.length - 1) {
      flatRef.current?.scrollToIndex({ index: currentIndex + 1, animated: true });
    } else {
      finish();
    }
  };

  const renderSlide = ({ item, index }: { item: typeof SLIDES[0]; index: number }) => (
    <View style={[styles.slide, { width: W, backgroundColor: item.bg }]}>
      {/* Large emoji icon */}
      <View style={[styles.emojiCircle, { borderColor: item.accent + '40', backgroundColor: item.accent + '18' }]}>
        <Text style={styles.emoji}>{item.emoji}</Text>
      </View>

      {/* Text */}
      <View style={styles.textBlock}>
        <Text style={styles.title}>{item.title}</Text>
        <Text style={styles.subtitle}>{item.subtitle}</Text>
      </View>

      {/* Accent bar */}
      <View style={[styles.accentBar, { backgroundColor: item.accent }]} />
    </View>
  );

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />

      {/* Skip */}
      <TouchableOpacity
        style={[styles.skipBtn, { top: insets.top + Spacing.sm }]}
        onPress={finish}
        hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
      >
        <Text style={styles.skipText}>Skip</Text>
      </TouchableOpacity>

      {/* Slides */}
      <FlatList
        ref={flatRef}
        data={SLIDES}
        renderItem={renderSlide}
        keyExtractor={(s) => s.id}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        scrollEventThrottle={16}
        onScroll={(e) => {
          scrollX.value = e.nativeEvent.contentOffset.x;
        }}
        onMomentumScrollEnd={(e) => {
          const idx = Math.round(e.nativeEvent.contentOffset.x / W);
          setCurrentIndex(idx);
        }}
        getItemLayout={(_, index) => ({ length: W, offset: W * index, index })}
      />

      {/* Bottom controls */}
      <View style={[styles.bottom, { paddingBottom: insets.bottom + Spacing.xl }]}>
        {/* Dots */}
        <View style={styles.dots}>
          {SLIDES.map((s, i) => (
            <DotIndicator
              key={s.id}
              index={i}
              scrollX={scrollX}
              accent={SLIDES[i].accent}
            />
          ))}
        </View>

        {/* CTA button */}
        <TouchableOpacity
          style={[styles.cta, { backgroundColor: SLIDES[currentIndex].accent }]}
          onPress={next}
          activeOpacity={0.85}
        >
          <Text style={styles.ctaText}>
            {currentIndex === SLIDES.length - 1 ? 'Get Started' : 'Continue'}
          </Text>
        </TouchableOpacity>

        {/* Already have account */}
        {currentIndex === SLIDES.length - 1 && (
          <TouchableOpacity onPress={finish} style={styles.loginLink}>
            <Text style={styles.loginLinkText}>Already have an account? Sign in</Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

// ── Animated dot indicator ────────────────────────────────────────────────────
function DotIndicator({ index, scrollX, accent }: {
  index: number; scrollX: Animated.SharedValue<number>; accent: string;
}) {
  const animStyle = useAnimatedStyle(() => {
    const inputRange = [(index - 1) * W, index * W, (index + 1) * W];
    const width = interpolate(
      scrollX.value, inputRange, [8, 24, 8], Extrapolation.CLAMP
    );
    const opacity = interpolate(
      scrollX.value, inputRange, [0.35, 1, 0.35], Extrapolation.CLAMP
    );
    return { width, opacity };
  });

  return (
    <Animated.View style={[styles.dot, animStyle, { backgroundColor: accent }]} />
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A0A0B' },
  skipBtn: {
    position: 'absolute', right: Spacing.xl, zIndex: 10,
    paddingHorizontal: Spacing.sm, paddingVertical: Spacing.xs,
  },
  skipText: {
    fontFamily: 'DMSans-Medium', fontSize: Typography.sm,
    color: 'rgba(255,255,255,0.5)',
  },
  slide: {
    flex: 1, alignItems: 'center', justifyContent: 'center',
    paddingHorizontal: Spacing['2xl'],
  },
  emojiCircle: {
    width: 140, height: 140, borderRadius: 70,
    alignItems: 'center', justifyContent: 'center',
    borderWidth: 1.5, marginBottom: Spacing['2xl'],
  },
  emoji: { fontSize: 64 },
  textBlock: { alignItems: 'center', gap: Spacing.base },
  title: {
    fontFamily: 'Playfair-Bold', fontSize: 34,
    color: '#FFFFFF', textAlign: 'center', lineHeight: 42, letterSpacing: -0.5,
  },
  subtitle: {
    fontFamily: 'DMSans-Regular', fontSize: Typography.base,
    color: 'rgba(255,255,255,0.6)', textAlign: 'center', lineHeight: 24,
    maxWidth: 320,
  },
  accentBar: {
    position: 'absolute', bottom: 0, left: 0, right: 0, height: 3,
  },
  bottom: {
    position: 'absolute', bottom: 0, left: 0, right: 0,
    paddingHorizontal: Spacing.xl, gap: Spacing.xl,
    alignItems: 'center',
  },
  dots: { flexDirection: 'row', gap: Spacing.sm, alignItems: 'center' },
  dot: { height: 8, borderRadius: 4 },
  cta: {
    width: '100%', height: 56, borderRadius: Radius.md,
    alignItems: 'center', justifyContent: 'center',
    shadowColor: '#000', shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3, shadowRadius: 12, elevation: 6,
  },
  ctaText: {
    fontFamily: 'DMSans-Bold', fontSize: Typography.md,
    color: '#FFFFFF', letterSpacing: 0.2,
  },
  loginLink: { paddingVertical: Spacing.xs },
  loginLinkText: {
    fontFamily: 'DMSans-Regular', fontSize: Typography.sm,
    color: 'rgba(255,255,255,0.45)',
  },
});
